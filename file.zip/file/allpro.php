<?php 

session_start();


 ?>
<!DOCTYPE html>
<html>
<head>
	<title>allpro_details</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<style type="text/css">
		th{
			text-align: center;
			font-family: all;
			font-size: 25px;
		  }
		 td{
		 	text-align: center;
		 	font-size: 17px;
		 }
	</style>

</head>
<body style="background-color: #CFD8DC;">

<div class="container-fluid">

	<nav class="navbar navbar-inverse navbar-fixed-top" style="padding: 1px;">
            <div class="navbar-header">
                <a class="navbar-brand"><b>BALAJI STONEX</b></a>
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#nav">
                        <span class="sr-only">Toggle Navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
            </div>
            <div class="collapse navbar-collapse" id="nav">
                <ul class="nav navbar-nav">
                    <li><a href="index.php">HOME</a></li>
                    
                    <li class="active"><a href="#">All Products</a></li>
                    <li><a href="#con">CONTACT</a></li>
                </ul>

                <ul class="nav navbar-nav navbar-right" style="margin-right: 20px;">
                    

                <?php 

                if (!(isset($_SESSION['email']) && $_SESSION['email'] !="")) 
                { ?>
                    <li class="active"><a href="lisu.php"><span class="fa fa-sign-in"></span> Log in / sign up</a></li>
                <?php      
                }
                else
                    {   
                        ?>
                        
                        <li class="active"><a href="#"><?php echo "Hey"."   ".$_SESSION["name"]; ?></a></li>
                        <li class="active"><a href="profile.php"><span class="fa fa-logout"></span>Profile</a></li>
                    <li class="active"><a href="logout.php"><span class="fa fa-logout"></span>logout</a></li>
                     
                
                    <?php  } 

                 ?>

                </ul>
            
            </div>
	</nav>
<br><br><br>


<?php 

include "form.php";

$sql="SELECT * FROM `product` order by id";
$result=mysqli_query($connect,$sql);

 ?>

<div class="row">
	
	<table border="4px" align="center" style="width: 1000px; line-height: 30px;" >
		<tr>
			<th colspan="6">
				<h3>All Product Details</h3>
			</th>
		</tr>

		<tr>
			<th>ID</th>
			<th>Category</th>
			<th>Name</th>
			<th>Price</th>
			<th>Size</th>
			<th>Details</th>

		</tr> 

		<?php 

			while ($rows=mysqli_fetch_assoc($result)) 
			{

				?>

				<tr>
					<td><?php echo $rows['id']; ?></td>
					<td><?php echo $rows['categories']; ?></td>
					<td><?php echo $rows['name']; ?></td>
					<td><?php echo $rows['price']; ?></td>
					<td><?php echo $rows['size']; ?></td>
					<td><?php echo $rows['details']; ?></td>
				</tr>
				
		<?php 	}
					 ?>

		
	</table>
</div>


		
</div>

</body>
</html>