<?php 

include "form.php";

$img=$_FILES['image']['name'];
$dst="C:/xampp/htdocs/file/img/".$img;
move_uploaded_file($_FILES['image']['tmp_name'],$dst);


$cat=$_POST['cat'];
$name=$_POST['pname']; 
$price=$_POST['pcost'];
$size=$_POST['psize'];
$details=$_POST['pdetail'];

$sql="INSERT INTO `product`(`categories`, `image`, `name`, `price`, `size`, `details`) VALUES ('$cat','$img','$name','$price','$size','$details')";


if (mysqli_query($connect,$sql)) 
{
	echo "<script>alert('Data Inserted .')
		window.location.assign('admin.php');
	</script>";
}

else
{
	echo "<script>alert('Data not Entered .')</script>";
}


 ?>
