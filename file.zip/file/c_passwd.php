<?php 
session_start();
include "form.php";
 
$passwd=$_POST['password'];

$qu=$_SESSION['email'];

$sql="UPDATE `user` SET `password`='$passwd' WHERE email='$qu'";

if (mysqli_query($connect,$sql)) 
{
	echo "<script>alert('Data Updated .')
			window.location.assign('index.php')
	</script>";
}
else
{
	echo "<script>alert('Data not Changed .')
		window.location.assign('profile.php')
	</script>";
}

 ?>

