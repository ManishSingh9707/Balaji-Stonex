<?php 
session_start();
include "form.php";
 
$sal=$_POST['salu'];
$fname=$_POST['f_name'];
$lname=$_POST['l_name'];
$addl1=$_POST['add_l1'];
$addl2=$_POST['add_l2'];
$country=$_POST['country'];
$state=$_POST['state'];
$city=$_POST['city'];
$code=$_POST['code'];
$phno=$_POST['phno'];
$email=$_POST['email'];
$passwd=$_POST['password'];

$qu=$_SESSION['email'];
$_SESSION['email']=$email;
$sql="UPDATE `user` SET `salutation`='$sal',`f_name`='$fname',`l_name`='$lname',`add_l1`='$addl1',`add_l2`='$addl2',`countrty`='$country',`state`='$state',`town`='$city',`zipcode`='$code',`phno`='$phno',`email`='$email',`password`='$passwd' WHERE email='$qu'";

if (mysqli_query($connect,$sql)) 
{
	echo "<script>alert('Data Updated .')
			window.location.assign('index.php')
	</script>";
}
else
{
	echo "<script>alert('Data not Changed .')
		window.location.assign('profile.php')
	</script>";
}

 ?>

