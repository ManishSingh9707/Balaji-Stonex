<?php 
session_start();

 ?>


<!DOCTYPE html>
<html>
<head>
	<title>balaji_stonex</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="css/ihover.css">
	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body style="background-color: #CFD8DC;">



<nav class="navbar navbar-inverse navbar-fixed-top" style="padding: 1px;">
			<div class="navbar-header">
				<a class="navbar-brand"><b>BALAJI STONEX</b></a>
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#nav">
						<span class="sr-only">Toggle Navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
			</div>
			<div class="collapse navbar-collapse" id="nav">
				<ul class="nav navbar-nav">
					<li class="active"><a href="index.php">HOME</a></li>
					
					<li><a href="about.php">ABOUT</a></li>
					<li><a href="#con">CONTACT</a></li>
				</ul>

				<ul class="nav navbar-nav navbar-right" style="margin-right: 20px;">
					

				<?php 

				if (!(isset($_SESSION['email']) && $_SESSION['email'] !="")) 
				{ ?>

					
					
					<li class="active"><a href="lisu.php"><span class="fa fa-sign-in"></span> Log in / Sign up</a></li>


				<?php   
					
				}

				else
					{
						if ($_SESSION['type']=="admin") 
						{  ?>
							<li class="active"><a href="admin.php"><span class="fa fa-logout"></span>Admin</a></li>
					<?php	}
						?>
						<li class="active"><a href="#"><?php echo "Hey"."   ".$_SESSION["name"]; ?></a></li>
						<li class="active"><a href="profile.php"><span class="fa fa-logout"></span>Profile</a></li>
					<li class="active"><a href="#"><span class="fa fa-shopping-cart"></span> cart</a></li>	
					<li class="active"><a href="logout.php"><span class="fa fa-logout"></span>logout</a></li>
				
					<?php  } 

				 ?>





				</ul>
			
			</div>
</nav>

<br><br><br><br>			








<div class="container-fluid">
	
		<div>
			<a href="index.php" style="padding: 5px;">Home</a> ><a href="wall.php"> Wall Tiles</a> > Cart
		</div>

<br>



	<div class="row">
		<div class="col-sm-5 well" style="background-color:  #90A4AE">
			<center>
				<img src="img/wall/w1.jpg" class="img responsive tpad" style="width: 90%; margin-bottom: 20PX;">
						<button type="submit" class="btn btn-default" style="background-color: #FFE082; padding: 18px;padding-right: 60px;padding-left: 60px;">
						Add to Cart
						</button>
						<button type="submit" class="btn btn-default" style="background-color: #9CCC65; margin-left: 12px; padding: 18px;padding-right: 60px;padding-left: 60px;">
						Buy Now
						</button>
			</center>
		</div>

		<div class="col-sm-7" style="padding-left: 60px;">
			<h3>DIGITAL WALL TILES</h3>
			<P>#Only on Balaji Stonex</P><br><h3>₹ 520 sq/feet <h4><strike>₹ 580 sq/feet</strike></h4></h3>
			<br>Size : 500 x 700 m m.<br><br><strong>Special Price </strong> Get extra ₹3000 off (Price inclusive of discount)<a href="#"> T & C</a>
			<br><strong>Bank Offer</strong> ₹ 2000 Cashback * on HDFC Bank Debit Cards <a href="#"> T & C</a>
			<br><strong>Wallet Offer</strong> ₹ 800 Cashback * on PhonePe  <a href="#"> T & C</a>
		</div>
	</div>






		<div class="row">
				<div class="col-sm-12" style="background-color: #455A64;padding: 40px;">
					<div class="col-sm-12" style="background-color: #90A4AE; padding: 20px;font-family: sans-serif; letter-spacing: 1px;text-align: center;">
						<div class="col-sm-12" style="align-content: center;">
							<a href="#"><img style="height: 35px;width: 35px;margin-left: 10px;" src="fb.png"></a>
							<a href="#"><img style="height: 35px;width: 35px;margin-left: 20px;" src="g+.png"></a>
							<a href="#"><img style="height: 35px;width: 35px;margin-left: 20px;" src="in.png"></a>
							<a href="#"><img style="height: 35px;width: 35px;margin-left: 20px;" src="yt.png"></a>
							<a href="#"><img style="height: 35px;width: 35px;margin-left: 20px;" src="ld.png"></a>
							<br>
							<br>
						</div>

						<b>Deals in : </b>Specialist in CERA TILES , JOHNSON TILES , ADVANCE TILES & KERVIT(KAJARIA) ,<br> SANATARY WARES ,BATH FITTINGS etc. 
						<br><br><b>| Corporate | CSR Activities | Awards & Certificates | Media Couverage | Career | </b>	
						<br><br><b>Address :</b> N.H-37 , Lalungagaon , Near NPS School , Guwahati-40 (ASSAM) 
						<br><b>E-mail :</b> balajistonex8297@gmail.com
						<br><b>:Ph no</b> : 9508064697<b>,</b>9707997897 <b>.</b>
						<b><hr ></b> 
						<br><b> &copy 2018 BALAJI STONEX PVT.LTD</b>	
					</div>
				</div>

		
		</div>









</div>
</body>