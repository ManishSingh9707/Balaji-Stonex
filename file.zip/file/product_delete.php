<?php 

include "form.php";

$id2=$_POST['id2'];
$cat2=$_POST['cat2'];

$sql2="select id from product where id='$id2'";
$sql="DELETE FROM `product` WHERE id='$id2' && categories='$cat2'";


if (mysqli_query($connect,$sql) && mysqli_query($connect,$sql2)) 
{
	echo "<script>alert('Data Deleted Successfully .')
		window.location.assign('admin.php');
	</script>";
}

else
{
	echo "<script>alert('Data not Matched.')</script>";
}

 ?> 