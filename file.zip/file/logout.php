<?php 

session_start();

session_unset($_SESSION['name']);
session_unset($_SESSION['email']);

header('location:index.php');


 ?>