<?php 
session_start();

if ((empty($_SESSION['name']))) 
{
	header('location:index.php');
} 

 ?>
 

<!DOCTYPE html>
<html>
<head>
	<title>balaji_stonex</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script type="text/javascript">
		function check()
		{
			var x=document.getElementById('pwd1').value;
			var y=document.getElementById('pwd2').value;
		
			if (x!=y) 
			{
				alert('Password Do Not Matched')
				return false;
			}
			
		}
	</script>
<body style="background-color: #CFD8DC;">

	<nav class="navbar navbar-inverse navbar-fixed-top" style="padding: 1px;">
			<div class="navbar-header">
				<a class="navbar-brand"><b>BALAJI STONEX</b></a>
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#nav">
						<span class="sr-only">Toggle Navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
			</div>
			<div class="collapse navbar-collapse" id="nav">
				<ul class="nav navbar-nav">
					<li class="active"><a href="index.php">HOME</a></li>
					
					<li><a href="about.php">ABOUT</a></li>
					<li><a href="#con">CONTACT</a></li>
				</ul>

				<ul class="nav navbar-nav navbar-right" style="margin-right: 20px;">
					

				<?php 

				if (!(isset($_SESSION['email']) && $_SESSION['email'] !="")) 
				{ ?>

					
					
					<li class="active"><a href="lisu.php"><span class="fa fa-sign-in"></span> Log in / Sign up</a></li>


				<?php   
					
				}

				else
					{
						if ($_SESSION['type']=="admin") 
						{  ?>
							<li class="active"><a href="admin.php"><span class="fa fa-logout"></span>Admin</a></li>
					<?php	}
						?>
						<li class="active"><a href="#"><?php echo "Hey"."   ".$_SESSION["name"]; ?></a></li>
						<li class="active"><a href="profile.php"><span class="fa fa-logout"></span>Profile</a></li>
					<li class="active"><a href="#"><span class="fa fa-shopping-cart"></span> cart</a></li>	
					<li class="active"><a href="logout.php"><span class="fa fa-logout"></span>logout</a></li>
				
					<?php  } 

				 ?>





				</ul>
			
			</div>
</nav>


		<div class="container-fluid" style="margin-top: 70px;">
			<hr>
			

			<div class="row">
				
				<div class="col-md-offset-2 col-md-9">
					<div class="col-md-11">

						<center><div class="col-md-12" style="font-size: 20px;">CHANGE PASSWORD</div></center>
						<hr><hr><br>





					<form method="post" action="c_passwd.php" onsubmit="return check()">
							




					


							<div class="form-group">
								<label for="dropdown"> New Password :<span style="color: red;font-size: 15px;"> *</span>  </label>
								<input type="Password" name="password" class="form-control" id="pwd1" required>
							</div>


							<div class="form-group">
								<label for="dropdown"> Retype Password :<span style="color: red;font-size: 15px;"> *</span>  </label>
								<input type="Password" name="re_password" class="form-control" id="pwd2" required>
							</div>


						<center><button type="submit" class="btn btn-default" style=" background-color: #42A5F5;">UPDATE</button></center>



						</form>

					</div>
				</div>
			</div>

			<br><br><br>

		</div>



			<div class="row">
				<div class="col-sm-12" style="background-color: #455A64;padding: 40px;">
					<div class="col-sm-12" style="background-color: #90A4AE; padding: 20px;font-family: sans-serif; letter-spacing: 1px;text-align: center;">
						<div class="col-sm-12" style="align-content: center;">
							<a href="#"><img style="height: 35px;width: 35px;margin-left: 10px;" src="fb.png"></a>
							<a href="#"><img style="height: 35px;width: 35px;margin-left: 20px;" src="g+.png"></a>
							<a href="#"><img style="height: 35px;width: 35px;margin-left: 20px;" src="in.png"></a>
							<a href="#"><img style="height: 35px;width: 35px;margin-left: 20px;" src="yt.png"></a>
							<a href="#"><img style="height: 35px;width: 35px;margin-left: 20px;" src="ld.png"></a>
							<br>
							<br>
						</div>

						<b>Deals in : </b>Specialist in CERA TILES , JOHNSON TILES , ADVANCE TILES & KERVIT(KAJARIA) ,<br> SANATARY WARES ,BATH FITTINGS etc. 
						<br><br><b>| Corporate | CSR Activities | Awards & Certificates | Media Couverage | Career | </b>	
						<br><br><b>Address :</b> N.H-37 , Lalungagaon , Near NPS School , Guwahati-40 (ASSAM) 
						<br><b>E-mail :</b> balajistonex8297@gmail.com
						<br><b>:Ph no</b> : 9508064697<b>,</b>9707997897 <b>.</b>
						<b><hr ></b> 
						<br><b> &copy 2018 BALAJI STONEX PVT.LTD</b>	
					</div>
				</div>
			</div>

			</div>

	 
</body>
</html>