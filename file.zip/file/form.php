<?php 

$server="localhost";
$user="root";
$password="";
$db_name="balajistonex";

$connect=mysqli_connect($server,$user,$password,$db_name);

if ($connect) 
{
	
}
else
{
	echo "not Connected";
}


 ?>