<?php 
include "form.php";

$email=$_POST['email']; 
$password=$_POST['password'];

$sql="SELECT `f_name`,`email`, `password` , `type` FROM `user` WHERE email='$email' && password='$password'";


if (mysqli_query($connect,$sql)) 
{
	

		session_start();
		$result=mysqli_query($connect,$sql);
		if (mysqli_num_rows($result)>0) 
		{
			$_SESSION['email']=$email;

			while ($row=mysqli_fetch_assoc($result)) 
			{
				$_SESSION['name']=$row['f_name'];
				$_SESSION['type']=$row['type'];
				header('location:index.php');
			}
		}

	 else
	{
		echo "<script>alert('Invalid Details .')
				window.location.assign('lisu.php') 
				</script>";
	}

}

 ?>