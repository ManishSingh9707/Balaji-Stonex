<?php 

session_start();

//echo $_SESSION['email'];

//die();
 ?>

<!DOCTYPE html>
<html>
<head>
	<title>balaji_stonex</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="css/ihover.css">
	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.0/animate.min.css">
</head>
<body style="background-color: #CFD8DC;">

<nav class="navbar navbar-inverse navbar-fixed-top" style="padding: 1px;">
			<div class="navbar-header">
				<a class="navbar-brand"><b>BALAJI STONEX</b></a>
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#nav">
						<span class="sr-only">Toggle Navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
			</div>
			<div class="collapse navbar-collapse" id="nav">
				<ul class="nav navbar-nav">
					<li class="active"><a href="#">HOME</a></li>
					
					<li><a href="about.php">ABOUT</a></li>
					<li><a href="#con">CONTACT</a></li>
				</ul>

				<ul class="nav navbar-nav navbar-right" style="margin-right: 20px;">
					

				<?php 

				if (!(isset($_SESSION['email']) && $_SESSION['email'] !="")) 
				{ ?>

					
					
					<li class="active"><a href="lisu.php"><span class="fa fa-sign-in"></span> Log in / Sign up</a></li>


				<?php   
					
				}

				else
					{
						if ($_SESSION['type']=="admin") 
						{  ?>
							<li class="active"><a href="admin.php"><span class="fa fa-logout"></span>Admin</a></li>
					<?php	}
						?>
						<li class="active"><a href="#"><?php echo "Hey..,"."   ".$_SESSION["name"]; ?></a></li>
						<li class="active"><a href="profile.php"><span class="fa fa-logout"></span>Profile</a></li>
					<li class="active"><a href="#"><span class="fa fa-shopping-cart"></span> cart</a></li>	
					<li class="active"><a href="logout.php"><span class="fa fa-logout"></span>logout</a></li>
				
					<?php  } 

				 ?>





				</ul>
			
			</div>
</nav>









<div class="container-fluid">
			
			

<div id="mycarousel" class="carousel slide  wow bounce" data-ride="carousel" style="margin-top: 55px;">
	<ol class="carousel-indicators">
		<li data-target="#mycarousel" data-slide-to="0" class="active" style="border-radius: 10px;"></li>
		<li data-target="#mycarousel" data-slide-to="1"></li>
		<li data-target="#mycarousel" data-slide-to="2"></li>
		<li data-target="#mycarousel" data-slide-to="3"></li>
	</ol>
	<div class="carousel-inner">
		<div class="item active">
			<img src="img/carosel/c1.jpg" style="height: 500px;width: 100%;" class="img resposnive tpad">
			<div class="carousel-caption"></div>
		</div>
		<div class="item">
			<img src="img/carosel/c2.jpg" style="height: 500px;width: 100%;" class="img responsive tpad">
		</div>
		<div class="item">
			<img src="img/carosel/c3.jpg" style="height: 500px;width: 100%;" class="img resposnive tpad">
		</div>
		<div class="item">
			<img src="img/carosel/c4.jpg" style="height: 500px;width: 100%;" class="img responsive tpad">
		</div>
	</div>
	<a href="#mycarousel" class="left carousel-control" data-slide="prev">
		<span class="glphyicon glphyicon-chevron-left">	</span>
		<span class="sr-only">previous</span>
	</a>
		<a href="#mycarousel" class="right carousel-control" data-slide="next">
		<span class="glphyicon glphyicon-chevron-right">	</span>
		<span class="sr-only">next</span>
	</a>
</div>
<script>
	$(function(){
		$('.carousel').carousel({
			interval:1000
		});
	})
</script>
</div>






<div class="container-fluid">

	<div class="row" style="margin-top: 10px;margin-bottom: 5px;">
		<div class="col-md-12">
			<div class="product wow jello delay-1s" style="text-align: center;background-color: #455A64;text-decoration-color: #212121;padding: 10px;border-radius: 20px;font-size: 25px;font-family: sans-serif;letter-spacing: 2px;">
				PRODUCT
			</div>
		</div>
	</div>


	<div class="row" style="margin-top: 15px;">
		<div class="col-md-3 wow zoomIn delay-1s" style=";padding: 0px;">
			
				<div class="ih-item square colored effect4">
					<a href="wall.php">
						<div class="img">
							<img src="img/home/wall.jpg" alt="img">
						</div>
						<div class="mask1"></div>
						<div class="mask2"></div>
						<div class="info">
							<h3 style="font-size: 25px;">WALL TILES</h3>
							<p>Enhance your walls with tiles beauty.</p>
						</div>
					</a>
				</div>
			
		</div>
			<div class="col-md-3 wow zoomIn delay-1s" style="padding: 0px;">
			
				<div class="ih-item square colored effect3 top_to_bottom">
					<a href="floor.php">
						<div class="img">
							<img src="img/home/floor2.jpg" alt="img">
						</div>
						<div class="info">
							<h3 style="font-size: 25px;">FLOOR TILES</h3>
							<p>Enhance your floor with tiles beauty.</p>
						</div>
					</a>
				</div>
			
		</div>
		<div class="col-md-3 wow zoomIn delay-1s" style="padding: 0px;">
			
				<div class="ih-item square colored effect4">
					<a href="sanitary.php">
						<div class="img">
							<img src="img/home/sanatry.jpg" alt="img">
						</div>
						<div class="mask1"></div>
						<div class="mask2"></div>
						<div class="info">
							<h3 style="font-size: 25px;">SANITRY ITEMS</h3>
							<p>Enhance your Bathroom with tiles beauty.</p>
						</div>
					</a>
				</div>
			
		</div>
		<div class="col-md-3 wow zoomIn delay-1s" style="padding: 0px;">
			
				<div class="ih-item square colored effect3 bottom_to_top">
					<a href="mirror.php">
						<div class="img">
							<img src="img/home/mirror.jpg" alt="img">
						</div>
						<div class="info">
							<h3 style="font-size: 25px;">MIRROR</h3>
							<p>Enhance the image , beauty.</p>
						</div>
					</a>
				</div>
			
		</div>
</div>

<br>
	<div class="row ">
	


			<div class="col-md-3 wow zoomIn delay-0.5s" style="padding: 0px;">
				<div class="ih-item square colored effect3 bottom_to_top">
					<a href="sink.php">
						<div class="img">
							<img src="img/home/sink.jpg" alt="img">
						</div>
						<div class="info">
							<h3 style="font-size: 25px;">KITICHEN SINK</h3>
							<p>Enhance your kitchen with Stainlees Steal beauty.</p>
						</div>
					</a>
				</div>
			</div>
			


			<div class="col-md-3 wow zoomIn delay-0.5s" style="padding: 0px;">
				<div class="ih-item square colored effect6">
					<a href="faculets.php">
						<div class="img">
							<img src="img/home/faucets.jpg" alt="img">
						</div>
						<div class="info">
							<h3 style="font-size: 25px;">FACULETS </h3>
							<p>Enhance your Bathrooms & Basins with beauty.</p>
						</div>
					</a>
				</div>
			</div>



			<div class="col-md-3 wow zoomIn delay-0.5s" style="padding: 0px;">
			
				<div class="ih-item square colored effect3 top_to_bottom">
					<a href="elevation.php">
						<div class="img">
							<img src="img/home/elevation.jpg" alt="img">
						</div>
						<div class="info">
							<h3 style="font-size: 25px;">ELEVATION</h3>
							<p>Enhance your Home with tiles beauty.</p>
						</div>
					</a>
				</div>
			</div>



		<div class="col-md-3 wow zoomIn delay-0.5s" style="padding: 0px;">
			
				<div class="ih-item square colored effect6">
					<a href="wellness.php">
						<div class="img">
							<img src="img/home/wellness.jpg" alt="img">
						</div>
						<div class="info">
							<h3 style="font-size: 25px;">WELLNESS</h3>
							<p>Enhance your Bathroom with Modern beauty.</p>
						</div>
					</a>
				</div>
		</div>
	


	</div>

<br>

		<div class="row">
				<div class="col-md-3 wow zoomIn delay-0.5s" style=";padding: 0px;">
					
						<div class="ih-item square colored effect4">
							<a href="granite.php">
								<div class="img">
									<img src="img/granite/g4.jpg" alt="img">
								</div>
								<div class="mask1"></div>
								<div class="mask2"></div>
								<div class="info">
									<h3 style="font-size: 25px;">GRANITE </h3>
									<p>Enhance your house with granite beauty.</p>
								</div>
							</a>
						</div>
					
				</div>
					<div class="col-md-3 wow zoomIn delay-0.5s" style="padding: 0px;">
					
						<div class="ih-item square colored effect3 top_to_bottom">
							<a href="marble.php">
								<div class="img">
									<img src="img/marble/m12.jpg" alt="img">
								</div>
								<div class="info">
									<h3 style="font-size: 25px;">Marble</h3>
									<p>Enhance your floor with Natural Marble beauty.</p>
								</div>
							</a>
						</div>
					
				</div>
				<div class="col-md-3 wow zoomIn delay-0.5s" style="padding: 0px;">
					
						<div class="ih-item square colored effect4">
							<a href="acs.php">
								<div class="img">
									<img src="img/acs/a8.jpg" alt="img" style="width: 100%;height: 200px;">
								</div>
								<div class="mask1"></div>
								<div class="mask2"></div>
								<div class="info">
									<h3 style="font-size: 25px;">ACCESSORIES</h3>
									<p>Helps to finish the work on time with beauty.</p>
								</div>
							</a>
						</div>
					
				</div>
				<div class="col-md-3 wow zoomIn delay-0.5s" style="padding: 0px;">
					
						<div class="ih-item square colored effect3 bottom_to_top">
							<a href="sintax.php">
								<div class="img">
									<img src="img/sintax/ks2.png" style="height: 250px;" alt="img">
								</div>
								<div class="info">
									<h3 style="font-size: 25px;">SINTAX</h3>
									<p>Enhance the power of water storage.</p>
								</div>
							</a>
						</div>
					
				</div>
		</div>





</div>


<br>

<div class="container-fluid ">
	<div class="row ">
		<div class="col-md-12" style="width: 100%">
			<center><a href="tour.php"><img src="360.jpg" class="img-responsive wow jello delay-1s "></a></center>
		</div>
	</div>
</div>


<br>

<div class="container-fluid">

	<div class="row" style="margin-top: 10px;">
		
		<div class="col-md-6 wow bounceInLeft  delay-2s">
			<center><h2><u>VISIT OUR STORE</u></h2>
			<p style="font-size: 18px;">For live experience of wide range of products. Our product range includes Indian Marble, Imported Marble, Granite range and multi coloured sand stones. Marble floor tile can have multiple finishes, from polished to honed and brushed to tumbled. Whether you combine similar or contrasting marble looks, this natural material has the “wow” factor that will impress your guests and completely transform your room.<br><br> Our most popular size of marble flooring tile is 8” x 20”, and the most traditional size is 12” x 12”. We also offer a multitude of square, plank and smaller mosaic tile patterns.
			<br><br>
			BALAJI STONEX offers a wide spectrum of experiences through an extensive range of products. To complement the Sanitaryware products there is a range of faucets, tiles, shower products, kitchen sinks and personal care products.</p></center>
		</div>

		<div class="col-md-6 wow bounceInRight delay-2s">
			<div class="panel panel-default">
				
				<div class="panel-heading" style="text-align: center;font-size: 18px; background-color: #455A64">
				<b>LOCATION</b>
				</div>

				<div class="panel-body" style="background-color: #90A4AE">
				<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14330.337236702624!2d91.73235061543909!3d26.112484906098942!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x375a5d1d39dddd95%3A0x1556d7dee633ef11!2sBalaji+Stonex+-+Tiles+and+Marbles+in+Guwahati!5e0!3m2!1sen!2sin!4v1539517985268" height="350" frameborder="0" style="border:0;width: 100%" allowfullscreen></iframe>
				</div>

			</div>
		</div>
	</div>

</div>
<br>







<div class="container-fluid">



	<!--  Modal  -->



	<div class="modal" id="mymodal2">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button class="close" type="button" data-dismiss="modal">
						X
					</button>
					<h2 class="modal-title" style="text-align: center;"> AWARDS </h2>
				</div>
				<div class="modal-body" style="padding-top: 0px; padding-bottom: 0px;">



					 <div class="row well" style="margin-bottom: 0px;background-color:  #90A4AE;">
					 	<div class="col-md-3 well">
					 		<img src="ic1.jpg" style="width: 70px;height: 70px;">
					 	</div>
					 	<div class="col-md-offset-1 col-md-8 well">
					 		 BALAJI STONEX, India’s most preferred premium home solutions brand, has been adjudged as a Trusted Brand, in a consumer survey conducted by Reader’s Digest.  BALAJI STONEX, for the past 35 years, have been on the forefront .
					 	</div>
					 </div>

					 <div class="row well" style="margin-bottom: 0px;background-color:  #90A4AE;">
					 	<div class="col-md-3 well">
					 		<img src="ic2.jpg" style="width: 70px;height: 70px;">
					 	</div>
					 	<div class="col-md-offset-1 col-md-8 well">
					 		In a nationwide consumer survey among 30,000 people conducted by Nielsen,   BALAJI STONEX’s Snow White has been voted Product of the Year in the sanitaryware category for 2011.  BALAJI STONEX Sanitaryware Limited, premium bathroom solutions provider.
					 	</div>
					 </div>
					 <div class="row well" style="margin-bottom: 0px;background-color:  #90A4AE;">
					 	<div class="col-md-3 well">
					 		<img src="ic3.jpg" style="width: 70px;height: 70px;">
					 	</div>
					 	<div class="col-md-offset-1 col-md-8 well">
					 		 BALAJI STONEX Sanitaryware Limited launched Cerenity, first toilet sanitizer in 2013. A study conducted reveals that women do not use public toilets because of hygiene reasons. Cerenity, the amazing new-age toilet seat sanitizer is developed.
					 	</div>
					 </div>
					 <div class="row well" style="margin-bottom: 0px;background-color:  #90A4AE;">
					 	<div class="col-md-3 well">
					 		<img src="ic5.jpg" style="width: 70px;height: 70px;">
					 	</div>
					 	<div class="col-md-offset-1 col-md-8 well">
					 		 BALAJI STONEX, India's most preferred home solutions provider, has bagged The Economic Times A&D Top 100 Brands award. The winningbrands are voted by 4000architects and interior designers based on popularity, quality and reputationbesides other parameters.
					 	</div>
					 </div>


					  <div class="row well" style="margin-bottom: 0px;background-color:  #90A4AE;">
					 	<div class="col-md-3 well">
					 		<img src="ic6.jpg" style="width: 70px;height: 70px;">
					 	</div>
					 	<div class="col-md-offset-1 col-md-8 well">
					 		Conformity European is a standard of measure, which is setby European committee for standardization purposes. Itincludeshuman hygiene, customer's safety and productsafety besides other parameters and it is valid across 32countries acrossEuropean Union.
					 	</div>
					 </div>
		
				</div>
			</div>
		</div>
	</div>




	




	<div class="modal" id="mymodal4">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button class="close" type="button" data-dismiss="modal">
						X
					</button>
					<h2 class="modal-title" style="text-align: center;"> SERVICES </h2>
				</div>
				<div class="modal-body"  style="padding-top: 0px; padding-bottom: 0px;">
					<div class="row">
						<div class="col-md-12">
							<div class="row" style="padding: 20px; background-color:  #90A4AE; text-align: center;font-size: 20px;">
							 Every home owner strives to create the perfect ambience in his home but also sensitive towards making changes in it.
							</div>
							<div class="row" style="padding: 20px; background-color: #CFD8DC;font-size: 15px;">
							 <b>Give single estimate for entire work and there are no hidden cost.
							</div>
							<div class="row" style="padding: 20px; background-color: #CFD8DC;font-size: 15px; ">
							 <b>Work is executed under the supervision of experienced engineers.
							</div>
							<div class="row" style="padding: 20px; background-color: #CFD8DC;font-size: 15px; ">
							<b> One stop for selection of materials.
							</div>
							<div class="row" style="padding: 20px; background-color: #CFD8DC;font-size: 15px; ">
							 <b>Single vendor for entire work and hence work become well -cordinated.
							</div>
							<div class="row" style="padding: 20px; background-color: #CFD8DC;font-size: 15px; ">
							<b> Minimum modification in cost with change on site or change in selection of product.
							</div>
							<div class="row" style="padding: 20px; background-color: #CFD8DC;font-size: 15px; "> 
							<b>All support material comes from BALAJI STONEX and its brand partners.
						</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>


<!-- End  -->









	<div class="row" style="margin-top: 20px;margin-bottom: 30px;margin-left: 15px;">
			

			<div class="col-sm-3 wow bounceInUp delay-1s" style="padding: 0px;">
				<div class="ih-item circle colored  effect5">
					<a href="tour.php"> 
						<div class="img">
							<img src="visit.jpg" alt="img">
						</div>
						<div class="info">
							<div class="info-back">
								<h3> VISIT US </h3>
								<p>Enhance your living experience .  </p>
							</div>
						</div>
					</a>
				</div>
			</div>


			<div class="col-sm-3 wow bounceInDown delay-1s" style="padding: 0px;">
				<div class="ih-item circle colored effect3  left_to_right">
					<a href="#" data-toggle="modal" data-target="#mymodal2">
						<div class="img">
							<img src="awards.jpg" alt="img">
						</div>
						<div class="info">
							<h3> AWARDS </h3>
							<p> Achivements in life make's life successful. </p>
						</div>
					</a>
				</div>
			</div>


			<div class="col-sm-3 wow bounceInUp delay-1s" style="padding: 0px;">
				<div class="ih-item circle colored effect2 left_to_right">
					<a href="grid/gallery.php">
						<div class="img">
							<img src="gall.png" alt="img">
						</div>
						<div class="info">
							<h3> Image Gallary</h3>
							<p> </p>
						</div>
					</a>
				</div>
			</div>
			


			<div class="col-md-3 wow bounceInDown delay-1s" style="padding: 0px;">
				<div class="ih-item circle colored effect15">
					<a href="#" data-toggle="modal" data-target="#mymodal4">
						<div class="img">
							<img src="service.png" alt="img">
						</div>
						<div class="info">
							<h3> SERVICES </h3>
							<p> Always ready to help with any query. </p>
						</div>
					</a>
				</div>
			</div>

		</div>








<!--
		<div class="row well">
			<div class="col-sm-12 well">
				<center>
					<h3><u>ABOUT</h3>
				</center>

					<div class="col-sm-6 well">
						<div class="col-md-4 well">
							<img src="">
						</div>
						<div class="col-md-8 well">
							
						</div>
					</div>
					<div class="col-sm-6 well">
						<div class="col-md-4 well">
							
						</div>
						<div class="col-md-8 well">
							
						</div>
					</div>
			</div>
		</div>

-->








		<div class="row wow  wow bounceInDown" id="con">
				<div class="col-sm-12" style="background-color: #455A64;padding: 40px;">
					<div class="col-sm-12" style="background-color: #90A4AE; padding: 20px;font-family: sans-serif; letter-spacing: 1px;text-align: center;">
						<div class="col-sm-12" style="align-content: center;">
							<a href="#"><img style="height: 35px;width: 35px;margin-left: 10px;" src="fb.png"></a>
							<a href="#"><img style="height: 35px;width: 35px;margin-left: 20px;" src="g+.png"></a>
							<a href="#"><img style="height: 35px;width: 35px;margin-left: 20px;" src="in.png"></a>
							<a href="#"><img style="height: 35px;width: 35px;margin-left: 20px;" src="yt.png"></a>
							<a href="#"><img style="height: 35px;width: 35px;margin-left: 20px;" src="ld.png"></a>
							<br>
							<br>
						</div>

						<b>Deals in : </b>Specialist in CERA TILES , JOHNSON TILES , ADVANCE TILES & KERVIT(KAJARIA) ,<br> SANATARY WARES ,BATH FITTINGS etc. 
						<br><br><b>| Corporate | CSR Activities | Awards & Certificates | Media Couverage | Career | </b>	
						<br><br><b>Address :</b> N.H-37 , Lalungagaon , Near NPS School , Guwahati-40 (ASSAM) 
						<br><b>E-mail :</b> balajistonex8297@gmail.com
						<br><b>:Ph no</b> : 9508064697<b>,</b>9707997897 <b>.</b>
						<b><hr ></b> 
						<br><b> &copy 2018 BALAJI STONEX PVT.LTD</b>	
					</div>
				</div>
			</div>
		</div>




<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>

<script src=https://cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.js> </script>
<script>
	var wow = new WOW(
  {
    boxClass:     'wow',      // animated element css class (default is wow)
    animateClass: 'animated', // animation css class (default is animated)
    offset:       0,          // distance to the element when triggering the animation (default is 0)
    mobile:       true,       // trigger animations on mobile devices (default is true)
    live:         true,       // act on asynchronously loaded content (default is true)
    callback:     function(box) {
      // the callback is fired every time an animation is started
      // the argument that is passed in is the DOM node being animated
    },
    scrollContainer: null,    // optional scroll container selector, otherwise use window,
    resetAnimation: true,     // reset animation on end (default is true)
  }
);
wow.init();

</script>

</body>
</html>