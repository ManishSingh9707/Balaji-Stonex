<?php 
include "form.php";
 
$sal=$_POST['salu'];
$fname=$_POST['f_name'];
$lname=$_POST['l_name'];
$addl1=$_POST['add_l1'];
$addl2=$_POST['add_l2'];
$country=$_POST['country'];
$state=$_POST['state'];
$city=$_POST['city'];
$code=$_POST['code'];
$phno=$_POST['phno'];
$email=$_POST['email'];
$passwd=$_POST['password'];

$sql="INSERT INTO user (salutation,f_name,l_name,add_l1,add_l2,countrty,state,town,zipcode,phno,email,password) VALUES ('$sal','$fname','$lname','$addl1','$addl2','$country','$state','$city','$code','$phno','$email','$passwd')";

if (mysqli_query($connect,$sql)) 
{
	echo "<script>alert('Data Entered .')
			window.location.assign('index.php')
	</script>";
}
else
{
	echo "<script>alert('Data not Entered .')</script>";
}


 ?>

