<?php 

session_start();



 ?>


<!DOCTYPE html>
<html>
<head>
 
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>aboutus</title>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css?family=Droid+Sans:400,700" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/baguettebox.js/1.8.1/baguetteBox.min.css">
    <link rel="stylesheet" href="gallery-grid.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.0/animate.min.css">



</head>
<body style="background-color: #CFD8DC;">


    <nav class="navbar navbar-inverse navbar-fixed-top" style="padding: 1px;">
            <div class="navbar-header">
                <a class="navbar-brand"><b>BALAJI STONEX</b></a>
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#nav">
                        <span class="sr-only">Toggle Navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
            </div>
            <div class="collapse navbar-collapse" id="nav">
                <ul class="nav navbar-nav">
                    <li><a href="index.php">HOME</a></li>
                    
                    <li class="active"><a href="about.php">ABOUT</a></li>
                    <li><a href="#con">CONTACT</a></li>
                </ul>

                <ul class="nav navbar-nav navbar-right" style="margin-right: 20px;">
                    

                <?php 

                if (!(isset($_SESSION['email']) && $_SESSION['email'] !="")) 
                { ?>

                    
                
                    <li class="active"><a href="lisu.php"><span class="fa fa-sign-in"></span> Log in / sign up</a></li>


                <?php   
                    
                }

                else
                    {  


                       
                        ?>
                        <li class="active"><a href="#"><?php echo "Hey"."   ".$_SESSION["name"]; ?></a></li>
                    <li class="active"><a href="logout.php"><span class="fa fa-logout"></span>logout</a></li>
                
                    <?php  } 

                 ?>





                </ul>
            
            </div>
</nav><br><br><br>


<div class="container-fluid">

    <div>
        <a href="index.php" style="padding: 20px;">Home</a>> About Us
    </div>



<div class="row">


    <div class="col-md-12" style="padding-left: 120px;padding-right: 150px; word-spacing: 4px;">
    
<br><br>
Style. Innovation. Leadership. <br> <br>

These three words capture the essence of BALAJI STONEX Sanitaryware Limited, India’s fastest growing company in the segment. Keeping the needs of the modern customer in mind, BALAJI STONEX opens the doorway to the world of style. <br> <br>

An extensive product portfolio that includes high end showers, steam cubicles, and whirlpools, besides sanitaryware and faucets, has made BALAJI STONEX the primary choice of customers looking for stylish products in a contemporary lifestyle. BALAJI STONEX’s constant innovations have given several path breaking contributions to the industry. Some of its innovations have become benchmarks for the industry–like water-saving twin-flush coupled WCs, 4-litre flush WCs, and one-piece WCs. <br> <br>

Advanced technology has been the forte of BALAJI STONEX. Its state-of-the-art manufacturing plant has been following the highest standards of quality with an emphasis on sustainability since its inception in 1980. The BALAJI STONEX plant was the first to use natural gas – the purest fuel that gives extra sheen on products. Production capacity of sanitaryware has raised from 2.70 million pieces to 3.0 million pieces per annum, BALAJI STONEX plans to maintain its leadership status in the industry, while catering to increasing demands with satisfaction. <br> <br>

BALAJI STONEX endeavors to provide complete bath solutions to its customers. Pursuing this objective, BALAJI STONEX has launched a range of elegant faucets, designed with style and expertise. A modern facility with latest machinery like automatic CNC machines & automatic polishing, the plant is equipped with superior technology manufactures the avant-garde collection of eco-friendly single lever faucets apart from the normal half turn & quarter turn faucets.  <br> <br>

Foraying into a new arena, BALAJI STONEX also launched an array of stylish wall and floor tiles. The range includes HD digital wall tiles with matching floor tiles, digital glazed vitrified tiles, and vitrified tiles with nano technology. <br> <br>

Growth has remained uninterrupted, only outperforming itself. BALAJI STONEX has grown at a robust 23.80% in 2014-15 when compared with 2013-14. For BALAJI STONEX, its responsibility does not end by manufacturing quality products. A team of over two hundred technicians across India provide prompt after-sales services to its customers. <br>

In keeping with its tradition of innovation, BALAJI STONEX has been presented the Gold Award in the bathroom & fittings and sanitaryware category by the Readers’ Digest Trusted Brand Survey. BALAJI STONEX has also bagged the Product of the Year award for four years in a row, for Cerenity in 2014, Sanitaryware & Bathroom Fittings in 2013, Nano Technology in 2012 and for the Snow White Range in 2011. BALAJI STONEX was conferred Power Brand for two years, in 2012 and 2013, which is awarded to top 100 brands in the country. BALAJI STONEX received Asia’s Most Promising Brand award for the year 2012-13. <br> <br>

With BALAJI STONEX, style blends with innovation to reveal a new dimension of modernity. BALAJI STONEX – Reflects your style. <br><br>

Regd.Office & Works: <br>
9,GIDC Industrial Estate, <br>
Kadi 382715, <br>
Dist. Mehsana, <br>
North Gujarat <br>
Phone: (02764) 242329, 262619, 262638, 263874, 321949 <br>
Telefax: (02764) 242465 <br>
Email: kadi@BALAJI STONEX-india.com <br>
 <br> <br>
Sales & Marketing Office: <br>
Madhusudan House, <br>
Opp. Navrangpura Telephone Exchange, <br>
Ahmedabad 380006 <br>
Phone: , 26449789 <br>
Fax: (079) 26569259 <br>
Email: marketing@BALAJI STONEX-india.com  <br>      


<br><br><br>

</div>

</div>




<div class="row"  id="con">
                <div class="col-sm-12" style="background-color: #455A64;padding: 40px;">
                    <div class="col-sm-12" style="background-color: #90A4AE; padding: 20px;font-family: sans-serif; letter-spacing: 1px;text-align: center;">
                        <div class="col-sm-12" style="align-content: center;">
                            <a href="#"><img style="height: 35px;width: 35px;margin-left: 10px;" src="fb.png"></a>
                            <a href="#"><img style="height: 35px;width: 35px;margin-left: 20px;" src="g+.png"></a>
                            <a href="#"><img style="height: 35px;width: 35px;margin-left: 20px;" src="in.png"></a>
                            <a href="#"><img style="height: 35px;width: 35px;margin-left: 20px;" src="yt.png"></a>
                            <a href="#"><img style="height: 35px;width: 35px;margin-left: 20px;" src="ld.png"></a>
                            <br>
                            <br>
                        </div>

                        <b>Deals in : </b>Specialist in CERA TILES , JOHNSON TILES , ADVANCE TILES & KERVIT(KAJARIA) ,<br> SANATARY WARES ,BATH FITTINGS etc. 
                        <br><br><b>| Corporate | CSR Activities | Awards & Certificates | Media Couverage | Career | </b>   
                        <br><br><b>Address :</b> N.H-37 , Lalungagaon , Near NPS School , Guwahati-40 (ASSAM) 
                        <br><b>E-mail :</b> balajistonex8297@gmail.com
                        <br><b>:Ph no</b> : 9508064697<b>,</b>9707997897 <b>.</b>
                        <b><hr ></b> 
                        <br><b> &copy 2018 BALAJI STONEX PVT.LTD</b>    
                    </div>
                </div>
            </div>
        </div>





</div>



</body>
</html>