<?php 

session_start();


 ?>

<!DOCTYPE html>
<html>
<head>
	<title>admin_page</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>

	<script type="text/javascript">
		
		function check()
		{
			var a=document.getElementById('cat').value;
			var b=document.getElementById('image').value;
			var c=document.getElementById('pname').value;
			var d=document.getElementById('pcost').value;
			var e=document.getElementById('psize').value;
			var f=document.getElementById('pdetail').value;
			var g=document.getElementById('id2').value;
			var h=document.getElementById('cat2').value;


			if (!isNaN(a))
			{
				alert('Please Fill all detail')
				return false;
			}
			if (!isNaN(b))
			{
				alert('Please Fill all detail')
				return false;
			}
			if (!isNaN(c))
			{
				alert('Please Fill all detail')
				return false;
			}
			if (isNaN(d))
			{
				alert('Please Fill all detail')
				return false;
			}
			if (!isNaN(e))
			{
				alert('Please Fill all detail')
				return false;
			}
			if (!isNaN(f))
			{
				alert('Please Fill all detail')
				return false;
			}
			if (isNaN(g))
			{
				alert('Please Fill all detail')
				return false;
			}
			if (!isNaN(h))
			{
				alert('Please Fill all detail')
				return false;
			}
		}
	</script>   
</head>
<body style="background-color: #CFD8DC;">


<div class="container-fluid">

	<nav class="navbar navbar-inverse navbar-fixed-top" style="padding: 1px;">
            <div class="navbar-header">
                <a class="navbar-brand"><b>BALAJI STONEX</b></a>
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#nav">
                        <span class="sr-only">Toggle Navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
            </div>
            <div class="collapse navbar-collapse" id="nav">
                <ul class="nav navbar-nav">
                    <li><a href="index.php">HOME</a></li>
                    
                    <li class="active"><a href="allpro.php">All Products</a></li>
                    <li><a href="#con">CONTACT</a></li>
                </ul>

                <ul class="nav navbar-nav navbar-right" style="margin-right: 20px;">
                    

                <?php 

                if (!(isset($_SESSION['email']) && $_SESSION['email'] !="")) 
                { ?>

                    
                
                    <li class="active"><a href="lisu.php"><span class="fa fa-sign-in"></span> Log in / sign up</a></li>


                <?php   
                    
                }

                else
                    {  


                       
                        ?>
                        <li class="active"><a href="#"><?php echo "Hey"."   ".$_SESSION["name"]; ?></a></li>
                    <li class="active"><a href="profile.php"><span class="fa fa-logout"></span>Profile</a></li>
                    <li class="active"><a href="logout.php"><span class="fa fa-logout"></span>logout</a></li>
                     
                
                    <?php  } 

                 ?>





                </ul>
            
            </div>
</nav>

<br><br><br>
	<center><h2>ADMIN PANEL</h2></center>

	<div class="row">
		<div class="col-md-6 ">
				<div class="row">
					<center><u><h2>Insert Product</h2></u></center><br>
				</div>
		<form action="product_insert.php" method="post" onsubmit="return check()" enctype="multipart/form-data">
							<div class="form-group">
								<label for="categories"> Categorie :<span  style="color: red;font-size: 15px;"> *</span>  </label>
								<select class="form-control" name="cat" id="cat">
									<option>Wall Tiles</option>
									<option>Kitchen Tiles</option>
									<option>Floor Tiles</option>
									<option>Marble</option>
									<option>Elevation</option>
									<option>Sanitary</option>
									<option>Mirror</option>
									<option>Wellnesess</option>
									<option>Faculets</option>
									<option>Sintax</option>
									<option>Granite</option>
									<option>Accessories</option>
								</select>
							</div>
							<div class="form-group">
								<label for="image"> Product Image :<span style="color: red;font-size: 15px;"> *</span>  </label>
								<input type="file" class="form-control" name="image" id="image" required>
							</div>

							<div class="form-group">
								<label for="name"> Product Name :<span style="color: red;font-size: 15px;"> *</span>  </label>
								<input type="text" class="form-control" name="pname" id="pname" required>
							</div>

							<div class="form-group">
								<label for="cost"> Product Cost :<span style="color: red;font-size: 15px;"> *</span>  </label>
								<input type="text" class="form-control" name="pcost" id="pcost" required>
							</div>

							<div class="form-group">
								<label for="size"> Product Size :<span style="color: red;font-size: 15px;"> *</span>  </label>
								<input type="text" class="form-control" name="psize" id="psize" required>
							</div>

							<div class="form-group">
								<label for="image"> Product Details :<span style="color: red;font-size: 15px;"> *</span>  </label>
								<input type="text" class="form-control" name="pdetail" id="pdetail" required style="height: 180px;">
							</div>
 							<button type="Insert" class="btn btn-default" style="background-color: #42A5F5;">Insert</button>
			</form>
		</div>

		<div class="col-md-6 ">
				<div class="row">
					<center><u><h2>Delete Product</h2></u></center><br>
				</div>


				<form action="product_delete.php" method="post">
							
							<div class="form-group">
								<label for="size"> Product ID :<span style="color: red;font-size: 15px;"> *</span>  </label>
								<input type="text" class="form-control" name="id2" id="id2" required>
							</div>

							<div class="form-group">
								<label for="categories"> Categorie :<span style="color: red;font-size: 15px;"> *</span>  </label>
								<select class="form-control" name="cat2" id="cat2">
									<option>Wall Tiles</option>
									<option>Kitchen Tiles</option>
									<option>Floor Tiles</option>
									<option>Marble</option>
									<option>Elevation</option>
									<option>Sanitary</option>
									<option>Mirror</option>
									<option>Wellnesess</option>
									<option>Faculets</option>
									<option>Sintax</option>
									<option>Granite</option>
									<option>Accessories</option>
								</select>
							</div>
 							<button type="Delete" class="btn btn-default" style="background-color: #42A5F5;">Delete</button>
			</form>


		</div>


	</div>
<br><br>

	<div class="row" id="con">
				<div class="col-sm-12" style="background-color: #455A64;padding: 40px;">
					<div class="col-sm-12" style="background-color: #90A4AE; padding: 20px;font-family: sans-serif; letter-spacing: 1px;text-align: center;">
						<div class="col-sm-12" style="align-content: center;">
							<a href="#"><img style="height: 35px;width: 35px;margin-left: 10px;" src="fb.png"></a>
							<a href="#"><img style="height: 35px;width: 35px;margin-left: 20px;" src="g+.png"></a>
							<a href="#"><img style="height: 35px;width: 35px;margin-left: 20px;" src="in.png"></a>
							<a href="#"><img style="height: 35px;width: 35px;margin-left: 20px;" src="yt.png"></a>
							<a href="#"><img style="height: 35px;width: 35px;margin-left: 20px;" src="ld.png"></a>
							<br>
							<br>
						</div>

						<b>Deals in : </b>Specialist in CERA TILES , JOHNSON TILES , ADVANCE TILES & KERVIT(KAJARIA) ,<br> SANATARY WARES ,BATH FITTINGS etc. 
						<br><br><b>| Corporate | CSR Activities | Awards & Certificates | Media Couverage | Career | </b>	
						<br><br><b>Address :</b> N.H-37 , Lalungagaon , Near NPS School , Guwahati-40 (ASSAM) 
						<br><b>E-mail :</b> balajistonex8297@gmail.com
						<br><b>:Ph no</b> : 9508064697<b>,</b>9707997897 <b>.</b>
						<b><hr ></b> 
						<br><b> &copy 2018 BALAJI STONEX PVT.LTD</b>	
					</div>
				</div>
			</div>

			</div>



</div>

</body>
</html>