<?php 
session_start();

 ?>

<!DOCTYPE html>
<html>
<head>
	<title>mirror</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>

<style>
	.panel-footer{
		 background-color: #B0BEC5;"
	}
	.panel-body{
		padding: 5px;
	}
</style> 

</head>
<body style="background-color: #CFD8DC;">
	<div class="container-fluid">
		

<nav class="navbar navbar-inverse navbar-fixed-top" style="padding: 1px;">
			<div class="navbar-header">
				<a class="navbar-brand"><b>BALAJI STONEX</b></a>
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#nav">
						<span class="sr-only">Toggle Navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
			</div>
			<div class="collapse navbar-collapse" id="nav">
				<ul class="nav navbar-nav">
					<li class="active"><a href="#index.php">HOME</a></li>
					
					<li><a href="about.php">ABOUT</a></li>
					<li><a href="#con">CONTACT</a></li>
				</ul>

				<ul class="nav navbar-nav navbar-right" style="margin-right: 20px;">
					

				<?php 

				if (!(isset($_SESSION['email']) && $_SESSION['email'] !="")) 
				{ ?>

					
					
					<li class="active"><a href="lisu.php"><span class="fa fa-sign-in"></span> Log in / Sign up</a></li>


				<?php   
					
				}

				else
					{
						if ($_SESSION['type']=="admin") 
						{  ?>
							<li class="active"><a href="admin.php"><span class="fa fa-logout"></span>Admin</a></li>
					<?php	}
						?>
						<li class="active"><a href="#"><?php echo "Hey"."   ".$_SESSION["name"]; ?></a></li>
						<li class="active"><a href="profile.php"><span class="fa fa-logout"></span>Profile</a></li>
					<li class="active"><a href="#"><span class="fa fa-shopping-cart"></span> cart</a></li>	
					<li class="active"><a href="logout.php"><span class="fa fa-logout"></span>logout</a></li>
				
					<?php  } 

				 ?>





				</ul>
			
			</div>
</nav><br><br><br>




<div class="row">
			<div class="col-md-12">
				<center><img src="img/mirror/head.jpg" style="width: 100%; " class="img responsive tpad"></center>
			</div>
		</div>
	
<br>

<div>
	<a href="index.php" style="padding: 5px;">Home</a> > Mirror
</div>

<br>


		<div class="row">
			<div class="col-md-3">
				<div class="panel panel-primary">
					
					<div class="panel-body" >
						<img src="img/mirror/m1.jpg" class="img responsive tpad" style="width: 100%;">
					</div>
					<div class="panel-footer">
						<center>Mirror BLK132 <br> size : 300 X 600 mm<br><b> Rs.1200 </b> </center>
					</div>
				</div>
			</div>


			<div class="col-md-3">
				<div class="panel panel-primary">
					
					<div class="panel-body">
						<img src="img/mirror/m2.jpg" class="img responsive tpad" style="width: 100%;">
					</div>
					<div class="panel-footer">
						<center>Mirror BLK152 <br> size : 300 X 600 mm<br><b> Rs.1300 </b> </center>
					</div>
				</div>
			</div>


			<div class="col-md-3">
				<div class="panel panel-primary">
					
					<div class="panel-body">
						<img src="img/mirror/m3.jpg" class="img responsive tpad" style="width: 100%;">
					</div>
					<div class="panel-footer">
						<center>Mirror BL2232 <br> size : 300 X 600 mm<br><b> Rs.1100 </b> </center>
					</div>
				</div>
			</div>


			<div class="col-md-3">
				<div class="panel panel-primary">
					
					<div class="panel-body">
						<img src="img/mirror/m4.jpg" class="img responsive tpad" style="width: 100%;">
					</div>
					<div class="panel-footer">
						<center>Mirror BLK1445 <br> size : 300 X 600 mm<br><b> Rs.1600 </b> </center>
					</div>
				</div>
			</div>


		</div>




		<div class="row">
			<div class="col-md-3">
				<div class="panel panel-primary">
					
					<div class="panel-body" >
						<img src="img/mirror/m5.jpg" class="img responsive tpad" style="width: 100%;">
					</div>
					<div class="panel-footer">
						<center>Mirror BLK342 <br> size : 300 X 600 mm<br><b> Rs.900 </b> </center>
					</div>
				</div>
			</div>


			<div class="col-md-3">
				<div class="panel panel-primary">
					
					<div class="panel-body">
						<img src="img/mirror/m6.jpg" class="img responsive tpad" style="width: 100%;">
					</div>
					<div class="panel-footer">
						<center>Mirror ALK132 <br> size : 300 X 600 mm<br><b> Rs.1240 </b> </center>
					</div>
				</div>
			</div>


			<div class="col-md-3">
				<div class="panel panel-primary">
					
					<div class="panel-body">
						<img src="img/mirror/m7.jpg" class="img responsive tpad" style="width: 100%;">
					</div>
					<div class="panel-footer">
						<center>Mirror BLWE132 <br> size : 300 X 600 mm<br><b> Rs.1280 </b> </center>
					</div>
				</div>
			</div>


			<div class="col-md-3">
				<div class="panel panel-primary">
					
					<div class="panel-body">
						<img src="img/mirror/m8.jpg" class="img responsive tpad" style="width: 100%;">
					</div>
					<div class="panel-footer">
						<center>Mirror DHHR132 <br> size : 300 X 600 mm<br><b> Rs.1560 </b> </center>
					</div>
				</div>
			</div>


		</div>





		<div class="row">
			<div class="col-md-3">
				<div class="panel panel-primary">
					
					<div class="panel-body" >
						<img src="img/mirror/m9.jpg" class="img responsive tpad" style="width: 100%;">
					</div>
					<div class="panel-footer">
						<center>Mirror BWE13W <br> size : 300 X 600 mm<br><b> Rs.1870 </b> </center>
					</div>
				</div>
			</div>


			<div class="col-md-3">
				<div class="panel panel-primary">
					
					<div class="panel-body">
						<img src="img/mirror/m10.jpg" class="img responsive tpad" style="width: 100%;">
					</div>
					<div class="panel-footer">
						<center>Mirror BDDF132 <br> size : 300 X 600 mm<br><b> Rs.1400 </b> </center>
					</div>
				</div>
			</div>


			<div class="col-md-3">
				<div class="panel panel-primary">
					
					<div class="panel-body">
						<img src="img/mirror/m11.jpg" class="img responsive tpad" style="width: 100%;">
					</div>
					<div class="panel-footer">
						<center>Mirror SAK142 <br> size : 300 X 600 mm<br><b> Rs.1600 </b> </center>
					</div>
				</div>
			</div>


			<div class="col-md-3">
				<div class="panel panel-primary">
					
					<div class="panel-body">
						<img src="img/mirror/m12.jpg" class="img responsive tpad" style="width: 100%;">
					</div>
					<div class="panel-footer">
						<center>Mirror BLK464 <br> size : 300 X 600 mm<br><b> Rs.1400 </b> </center>
					</div>
				</div>
			</div>


	</div>		

			<div class="row">
				<div class="col-md-3">
					<div class="panel panel-primary">
					
					<div class="panel-body" >
						<img src="img/mirror/m13.jpg" class="img responsive tpad" style="width: 100%;">
					</div>
					<div class="panel-footer">
						<center>Mirror BLK232 <br> size : 300 X 600 mm<br><b> Rs.2200 </b> </center>
					</div>
					</div>
				</div>


				<div class="col-md-3">
					<div class="panel panel-primary">
					
					<div class="panel-body">
						<img src="img/mirror/m14.jpg" class="img responsive tpad" style="width: 100%;">
					</div>
					<div class="panel-footer">
						<center>Mirror ERT132 <br> size : 300 X 600 mm<br><b> Rs.2000 </b> </center>
					</div>
					</div>
				</div>


				<div class="col-md-3">
					<div class="panel panel-primary">
					
					<div class="panel-body">
						<img src="img/mirror/m15.jpg" class="img responsive tpad" style="width: 100%;">
					</div>
					<div class="panel-footer">
						<center>Mirror RTY132 <br> size : 300 X 600 mm<br><b> Rs.1250 </b> </center>
					</div>
					</div>
				</div>


				<div class="col-md-3">
					<div class="panel panel-primary">
					
					<div class="panel-body">
						<img src="img/mirror/m16.jpg" class="img responsive tpad" style="width: 100%;">
					</div>
					<div class="panel-footer">
						<center>Mirror BLK465 <br> size : 300 X 600 mm<br><b> Rs.1560 </b> </center>
					</div>
					</div>
				</div>


		</div>





		<div class="row">
			<div class="col-md-3">
				<div class="panel panel-primary">
					
					<div class="panel-body" >
						<img src="img/mirror/m17.jpg" class="img responsive tpad" style="width: 100%;">
					</div>
					<div class="panel-footer">
						<center>Mirror BLK132 <br> size : 300 X 600 mm<br><b> Rs.1200 </b> </center>
					</div>
				</div>
			</div>


			<div class="col-md-3">
				<div class="panel panel-primary">
					
					<div class="panel-body">
						<img src="img/mirror/m18.jpg" class="img responsive tpad" style="width: 100%;">
					</div>
					<div class="panel-footer">
						<center>Mirror ADDF34 <br> size : 300 X 600 mm<br><b> Rs.1500 </b> </center>
					</div>
				</div>
			</div>


			<div class="col-md-3">
				<div class="panel panel-primary">
					
					<div class="panel-body">
						<img src="img/mirror/m19.jpg" class="img responsive tpad" style="width: 100%;">
					</div>
					<div class="panel-footer">
						<center>Mirror ETG132 <br> size : 300 X 600 mm<br><b> Rs.1450 </b> </center>
					</div>
				</div>
			</div>


			<div class="col-md-3">
				<div class="panel panel-primary">
					
					<div class="panel-body">
						<img src="img/mirror/m20.jpg" class="img responsive tpad" style="width: 100%;">
					</div>
					<div class="panel-footer">
						<center>Mirror B5ERF32 <br> size : 300 X 600 mm<br><b> Rs.1640 </b> </center>
					</div>
				</div>
			</div>


		</div>


		<div class="row" id="con">
				<div class="col-sm-12" style="background-color: #455A64;padding: 40px;">
					<div class="col-sm-12" style="background-color: #90A4AE; padding: 20px;font-family: sans-serif; letter-spacing: 1px;text-align: center;">
						<div class="col-sm-12" style="align-content: center;">
							<a href="#"><img style="height: 35px;width: 35px;margin-left: 10px;" src="fb.png"></a>
							<a href="#"><img style="height: 35px;width: 35px;margin-left: 20px;" src="g+.png"></a>
							<a href="#"><img style="height: 35px;width: 35px;margin-left: 20px;" src="in.png"></a>
							<a href="#"><img style="height: 35px;width: 35px;margin-left: 20px;" src="yt.png"></a>
							<a href="#"><img style="height: 35px;width: 35px;margin-left: 20px;" src="ld.png"></a>
							<br>
							<br>
						</div>

						<b>Deals in : </b>Specialist in CERA TILES , JOHNSON TILES , ADVANCE TILES & KERVIT(KAJARIA) ,<br> SANATARY WARES ,BATH FITTINGS etc. 
						<br><br><b>| Corporate | CSR Activities | Awards & Certificates | Media Couverage | Career | </b>	
						<br><br><b>Address :</b> N.H-37 , Lalungagaon , Near NPS School , Guwahati-40 (ASSAM) 
						<br><b>E-mail :</b> balajistonex8297@gmail.com
						<br><b>:Ph no</b> : 9508064697<b>,</b>9707997897 <b>.</b>
						<b><hr ></b> 
						<br><b> &copy 2018 BALAJI STONEX PVT.LTD</b>	
					</div>
				</div>


		
	</div>


		

	</div>




	</div>
</body>
</html>