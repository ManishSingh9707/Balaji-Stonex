<?php 

session_start();


 ?>
<!DOCTYPE html>
<html>
<head>
	<title>user_details</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<style type="text/css">
		th{
			text-align: center;
			font-family: all;
			font-size: 25px;
		  }
		 td{
		 	text-align: center;
		 	font-size: 17px;
		 }
	</style>

</head>
<body style="background-color: #CFD8DC;">

<div class="container-fluid">

	<nav class="navbar navbar-inverse navbar-fixed-top" style="padding: 1px;">
            <div class="navbar-header">
                <a class="navbar-brand"><b>BALAJI STONEX</b></a>
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#nav">
                        <span class="sr-only">Toggle Navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
            </div>
            <div class="collapse navbar-collapse" id="nav">
                <ul class="nav navbar-nav">
                    <li><a href="index.php">HOME</a></li>
                    
                    <li><a href="about.php">ABOUT</a></li>
                    <li><a href="#con">CONTACT</a></li>
                </ul>

                <ul class="nav navbar-nav navbar-right" style="margin-right: 20px;">
                    

                <?php 

                if (!(isset($_SESSION['email']) && $_SESSION['email'] !="")) 
                { ?>
                    <li class="active"><a href="lisu.php"><span class="fa fa-sign-in"></span> Log in / sign up</a></li>
                <?php      
                }
                else
                    {   
                        ?>
                        <li class="active"><a href="#"><?php echo "Hey"."   ".$_SESSION["name"]; ?></a></li>
                         <li class="active"><a href="profile.php"><span class="fa fa-logout"></span>Profile</a></li>
                    <li class="active"><a href="logout.php"><span class="fa fa-logout"></span>logout</a></li>
                    
                
                    <?php  } 

                 ?>

                </ul>
            
            </div>
	</nav>
<br><br><br>


<?php 

include "form.php";
$fname=$_SESSION['email'];
$sql="select * from user  where email='$fname'";
$result=mysqli_query($connect,$sql);

 ?>

<div class="row">
	
	<table border="4px" align="center" style="width: 800px; line-height: 40px;" >

		<tr>
			<th colspan="2"><h3>USER DETAIL</h3></th>
		</tr>
		<?php 

			while ($rows=mysqli_fetch_assoc($result)) 
			{

				?>
		<tr>
			<td>Name : </td>
			<td><?php echo $rows['f_name']."  ".$rows['l_name']; ?></td>
		</tr>
		<tr>
			<td>E-mail : </td>
			<td><?php echo $rows['email']; ?></td>
		</tr>
		<tr>
			<td>Address : </td>
			<td><?php echo $rows['add_l1']."  ".$rows['add_l2']; ?></td>
		</tr>
		<tr>
			<td>Town / City : </td>
			<td><?php echo $rows['town']; ?></td>
		</tr>
		<tr>
			<td>Zip Code : </td>
			<td><?php echo $rows['zipcode']; ?></td>
		</tr>
		<tr>
			<td>Phone no : </td>
			<td><?php echo $rows['phno']; ?></td>
		</tr>
		<tr>
			<td>Acount Type : </td>
			<td><?php echo $rows['type']; ?></td>
		</tr>


	<?php 	}
				 ?>

	</table>

	<br><br>

	<div class="row">
		<center><a href="update.php"><div class="col-md-offset-3 col-md-2 well" style="background-color: #42A5F5;padding: 17px;"><b> EDIT PROFILE </b></div></a>
			&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
		<a href="change_p.php"><div class="col-md-offset-2 col-md-2 well" style="background-color: #42A5F5;padding: 17px;"><b> CHANGE PASSWORD </b></div></a></center>
	</div>
		
</div>


		
</div>

</body>
</html>