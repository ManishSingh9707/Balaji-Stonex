<?php 
session_start();

if (!(empty($_SESSION['name']))) 
{
	header('location:index.php');
} 

 ?>
 

<!DOCTYPE html>
<html>
<head>
	<title>balaji_stonex</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script type="text/javascript">
		function check()
		{
			var x=document.getElementById('pwd1').value;
			var y=document.getElementById('pwd2').value;
			var a=document.getElementById('fn').value;
			var b=document.getElementById('ln').value;
			var c=document.getElementById('ad1').value;
			var d=document.getElementById('ad2').value;
			var e=document.getElementById('con').value;
			var f=document.getElementById('st').value;
			var g=document.getElementById('ct').value;
			var h=document.getElementById('zc').value;
			var i=document.getElementById('ph').value;
			var j=document.getElementById('em').value;
			if (x!=y) 
			{
				alert('Password Do Not Matched')
				return false;
			}
			if (!isNaN(a))
			{
				alert('Please Fill F name')
				return false;
			}
			if (!isNaN(b))
			{
				alert('Please Fill l name')
				return false;
			}
			if (!isNaN(c))
			{
				alert('Please Fill add1')
				return false;
			}
			if (!isNaN(d))
			{
				alert('Please Fill add2')
				return false;
			}
			if (!isNaN(e))
			{
				alert('Please Fill con')
				return false;
			}
			if (!isNaN(f))
			{
				alert('Please Fill state')
				return false;
			}
			if (!isNaN(g))
			{
				alert('Please Fill city')
				return false;
			}
			
			if (!isNaN(j))
			{
				alert('Please Fill email')
				return false;
			}
		}
	</script>
<body style="background-color: #CFD8DC;">

	<nav class="navbar navbar-inverse navbar-fixed-top" style="padding: 1px;">
			<div class="navbar-header">
				<a class="navbar-brand"><b>BALAJI STONEX</b></a>
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#nav">
						<span class="sr-only">Toggle Navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
			</div>

			<div class="collapse navbar-collapse" id="nav">
				<ul class="nav navbar-nav">
					<li class="active"><a href="index.php">HOME</a></li>
					
					<li><a href="about.php">ABOUT</a></li>
					<li><a href="#">CONTACT</a></li>
				</ul>

				<ul class="nav navbar-nav navbar-right" style="margin-right: 20px;">
					
					
					<li class="active"><a href="lisu.php"><span class="fa fa-sign-in"></span> Log in / sing up</a></li>
				</ul>
			
			</div>
		</nav>


		<div class="container-fluid" style="margin-top: 70px;">
			<hr>
			<div class="row">
				<div class="col-md-12" style="margin-left: 20px;">
					<a href="index.php" style="text-decoration: none;"> Home</a> > My acount
				</div>
			</div>
			<div class="row">
				<div class="col-md-12" style="text-align: center;padding: 20px; font-size: 30px;font-family: sans-serif;color: #42A5F5;">
					LOGIN / REGISTRATION
				</div>
			</div>

			<div class="row">
				<div class="col-md-6">
					<div class="col-md-11">

						<div class="col-md-12" style="font-size: 20px;">Login </div>
						<hr><hr><br>	
						<form method="post" action="login.php">
							<div class="form-group">
								<label for="email"> Email address :<span style="color: red;font-size: 15px;"> *</span>  </label>
								<input type="email" class="form-control" name="email" id="email" required>
							</div>
							
							<div class="form-group">
								<label for="Password"> Password :<span style="color: red;font-size: 15px;"> *</span>  </label>
								<input type="Password" class="form-control" name="password" id="pwd" required>
							</div>

							<div class="checkbox">
  							  <label><input type="checkbox"> Remember me</label>
							</div>

 							<button type="submit" class="btn btn-default" style="background-color: #42A5F5;">Submit</button>
						</form>
					</div>
				</div>
				







				<div class="col-md-6">
					<div class="col-md-11">

						<div class="col-md-12" style="font-size: 20px;">Register </div>
						<hr><hr><br>





					<form method="post" action="user.php" onsubmit="return check()">
							




					<div class="col-md-2" style="padding: 0px;">
							<div class="form-group">
								<label for="name"> Salutation :<span style="color: red;font-size: 15px;"> *</span>  </label>
								<select class="form-control" name="salu">
									<option>Mr</option>
									<option>Mrs</option>
									<option>Ms</option>
								</select>
							</div>
					</div>
					<div class="col-md-offset-1 col-md-4" style="padding: 0px;">
							<div class="form-group">
								<label for="name"> First Name :<span style="color: red;font-size: 15px;"> *</span>  </label>
								<input type="text" name="f_name" class="form-control" id="fn" required>
							</div>
					</div>
					<div class="col-md-offset-1 col-md-4" style="padding: 0px;">
							<div class="form-group">
								<label for="name"> Last Name :<span style="color: red;font-size: 15px;"> *</span>  </label>
								<input type="text" name="l_name" class="form-control" id="ln" required>
							</div>
					</div>
					

							<div class="form-group">
								<label for="address"> Address Line 1 :<span style="color: red;font-size: 15px;"> *</span>  </label>
								<input type="address" name="add_l1" class="form-control" id="ad1" required>
							</div>	

							<div class="form-group">
								<label for="address"> Address Line 2 :<span style="color: red;font-size: 15px;"> *</span>  </label>
								<input type="address" name="add_l2" class="form-control" id="ad2" required>
							</div>


						<div class="col-md-5" style="padding: 0px;">
							<div class="form-group">
								<label for="country"> Country :<span style="color: red;font-size: 15px;"> *</span>      </label>
								<input type="text" name="country" class="form-control" id="con">
							</div>
						</div>
						
						<div class="col-md-offset-2 col-md-5" style="padding: 0px;">
							<div class="form-group">
								<label for="state"> State :<span style="color: red;font-size: 15px;"> *</span> </label>
								<select class="form-control" name="state" id="st">
									<option>Andhra Pradesh</option>
									<option>Arunachal Pradesh</option>
									<option>Assam</option>
									<option>Bihar</option>
									<option>Chhattisgarh</option>
									<option>Goa</option>
									<option>Gujarat</option>
									<option>Haryana</option>
									<option>Himachal Pradesh</option>
									<option>Jammu and Kashmir</option>
									<option>Jharkhand</option>
									<option>Karnataka</option>
									<option>Kerala</option>
									<option>Madhya Pradesh</option>
									<option>Maharashtra</option>
									<option>Manipur</option>
									<option>Meghalaya</option>
									<option>Mizoram</option>
									<option>Nagaland</option>
									<option>Odisha</option>
									<option>Punjab</option>
									<option>Rajasthan</option>
									<option>Sikkim</option>
									<option>Tamil Nadu</option>
									<option>Telangana</option>
									<option>Tripura</option>
									<option>Uttarakhand</option>
									<option>Uttar Pradesh</option>
									<option>West Bengal</option>
									<option>Andaman and Nicobar Islands</option>
									<option>Chandigarh</option>
									<option>Dadra and Nagar Haveli</option>
									<option>Daman and Diu</option>
									<option>Delhi</option>
									<option>Lakshadweep</option>
									<option>Puducherry</option>
								</select>
							</div>
						</div>

						<div class="col-md-5" style="padding: 0px;">
							<div class="form-group">
								<label for="country"> Town/City :<span style="color: red;font-size: 15px;"> *</span>  </label>
								<input type="text" name="city" class="form-control" id="ct">
							</div>
						</div>
						<div class="col-md-offset-2 col-md-5" style="padding: 0px;">
							<div class="form-group">
								<label for="state"> Zipcode :<span style="color: red;font-size: 15px;"> *</span>  </label>
								<input type="text" name="code" maxlength="6" minlength="6" class="form-control" id="zc">
							</div>
						</div>


						<div class="form-group">
								<label for="dropdown"> Phone no :<span style="color: red;font-size: 15px;"> *</span>  </label>
								<input type="text" name="phno" minlength="10" maxlength="10" class="form-control" id="ph" required>
							</div>

						<div class="form-group">
								<label for="dropdown"> Email Address :<span style="color: red;font-size: 15px;"> *</span>  </label>
								<input type="email" name="email" class="form-control" id="em" required>
							</div>


							<div class="form-group">
								<label for="dropdown"> New Password :<span style="color: red;font-size: 15px;"> *</span>  </label>
								<input type="Password" name="password" class="form-control" id="pwd1" required>
							</div>


							<div class="form-group">
								<label for="dropdown"> Retype Password :<span style="color: red;font-size: 15px;"> *</span>  </label>
								<input type="Password" name="re_password" class="form-control" id="pwd2" required>
							</div>


						<button type="submit" class="btn btn-default" style="float: right; background-color: #42A5F5;">Register</button>



						</form>

					</div>
				</div>
			</div>

			<br><br><br>

		</div>


			<div class="container-fluid">

			<div class="row">
				<div class="col-sm-12" style="background-color: #455A64;padding: 40px;">
					<div class="col-sm-12" style="background-color: #90A4AE; padding: 20px;font-family: sans-serif; letter-spacing: 1px;text-align: center;">
						<div class="col-sm-12" style="align-content: center;">
							<a href="#"><img style="height: 35px;width: 35px;margin-left: 10px;" src="fb.png"></a>
							<a href="#"><img style="height: 35px;width: 35px;margin-left: 20px;" src="g+.png"></a>
							<a href="#"><img style="height: 35px;width: 35px;margin-left: 20px;" src="in.png"></a>
							<a href="#"><img style="height: 35px;width: 35px;margin-left: 20px;" src="yt.png"></a>
							<a href="#"><img style="height: 35px;width: 35px;margin-left: 20px;" src="ld.png"></a>
							<br>
							<br>
						</div>

						<b>Deals in : </b>Specialist in CERA TILES , JOHNSON TILES , ADVANCE TILES & KERVIT(KAJARIA) ,<br> SANATARY WARES ,BATH FITTINGS etc. 
						<br><br><b>| Corporate | CSR Activities | Awards & Certificates | Media Couverage | Career | </b>	
						<br><br><b>Address :</b> N.H-37 , Lalungagaon , Near NPS School , Guwahati-40 (ASSAM) 
						<br><b>E-mail :</b> balajistonex8297@gmail.com
						<br><b>:Ph no</b> : 9508064697<b>,</b>9707997897 <b>.</b>
						<b><hr ></b> 
						<br><b> &copy 2018 BALAJI STONEX PVT.LTD</b>	
					</div>
				</div>
			</div>

			</div>

	</div>

</body>
</html>