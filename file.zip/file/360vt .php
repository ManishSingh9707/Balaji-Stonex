<!DOCTYPE html>
<html>
<head>
	<title>map</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
</head>
<body style="background-color: #CFD8DC;">

		<nav class="navbar navbar-inverse navbar-fixed-top" style="padding: 1px;">
			<div class="navbar-header">
				<a class="navbar-brand"><b>BALAJI STONEX</b></a>
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#nav">
						<span class="sr-only">Toggle Navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
			</div>

			<div class="collapse navbar-collapse" id="nav">
				<ul class="nav navbar-nav">
					<li class="active"><a href="home.html">HOME</a></li>
				
					<li><a href="about.html">ABOUT</a></li>
					<li><a href="#">CONTACT</a></li>
				</ul>

				<ul class="nav navbar-nav navbar-right" style="margin-right: 20px;">
					<li class="active"><a href="lisu.html"><span class="fa fa-shopping-cart"></span> cart</a></li>
					<li class="active"><a href="lisu.html"><span class="fa fa-user"></span>   Sign up</a></li>
					<li class="active"><a href="lisu.html"><span class="fa fa-sign-in"></span> Log in</a></li>				</ul>
			
			</div>
		</nav>
		<br><br><br>




	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
				<div class="panel panel-primary">
					<div class="panel-heading" style="background-color: #455A64;">
						NORTH - SECTION - VIEW
					</div>
					<div class="panel-body" style="background-color: #90A4AE;">
					<iframe src="https://www.google.com/maps/embed?pb=!4v1539516306916!6m8!1m7!1sCAoSLEFGMVFpcE5vT1JjWTRhZHV3ZjJUSFIxdEE2bHNhanVPcnF0LTFZNzNUOEpT!2m2!1d26.111790062178!2d91.739366675501!3f143.20733485440033!4f5.739980981762557!5f0.7820865974627469" height="600" frameborder="0" style="border:0;width: 100%;" allowfullscreen></iframe>
					</div>
				</div>
			</div>
		</div>

		<div class="row">
			<div class="col-md-12">
				<div class="panel panel-primary">
					<div class="panel-heading" style="background-color: #455A64;">
						EAST - SECTION - VIEW
					</div>
					<div class="panel-body" style="background-color: #90A4AE;">
					<iframe src="https://www.google.com/maps/embed?pb=!4v1539517512008!6m8!1m7!1sCAoSLEFGMVFpcE5sWDVpQm1peGxwTFhZTllmR1p3dFphM0htaVlqNDlmeGVkSW0x!2m2!1d26.111869802399!2d91.739278067333!3f213.27056609529768!4f-12.059724059124719!5f0.7820865974627469" height="600" frameborder="0" style="border:0;width: 100%;" allowfullscreen></iframe>
					</div>
				</div>
			</div>
		</div>



		<div class="row">
			<div class="col-md-12">
				<div class="panel panel-primary">
					<div class="panel-heading" style="background-color: #455A64;">
						SOUTH - SECTION - VIEW
					</div>
					<div class="panel-body" style="background-color: #90A4AE;">
					
						<iframe src="https://www.google.com/maps/embed?pb=!4v1539517630853!6m8!1m7!1sCAoSLEFGMVFpcE5Jdno5M3BUUWt2aTdncUVYTTg4V2lrcU9ZWVNRSmsyaXhpY2dT!2m2!1d26.111821211719!2d91.739391307299!3f303.28750330979364!4f-21.751907288860934!5f0.7820865974627469" height="600" frameborder="0" style="border:0;width: 100%;" allowfullscreen></iframe>
					</div>
				</div>
			</div>
		</div>

				<div class="row">
			<div class="col-md-12">
				<div class="panel panel-primary">
					<div class="panel-heading" style="background-color: #455A64;">
						WEST - SECTION - VIEW
					</div>
					<div class="panel-body" style="background-color: #90A4AE;">
					
						<iframe src="https://www.google.com/maps/embed?pb=!4v1539517818650!6m8!1m7!1sCAoSLEFGMVFpcFBaR18zMUphLXBnRkw4VFBxQ1lBM3plRGE1Wk9lRUl5MWwyNkdk!2m2!1d26.111829808454!2d91.739174155173!3f189.33678709729688!4f-6.527320393047816!5f0.7820865974627469" height="600" frameborder="0" style="border:0;width: 100%;" allowfullscreen></iframe>
					</div>
				</div>
			</div>
		</div>


		<br>

			<div class="row">
				<div class="col-sm-12" style="background-color: #455A64;padding: 40px;">
					<div class="col-sm-12" style="background-color: #90A4AE; padding: 20px;font-family: sans-serif; letter-spacing: 1px;text-align: center;">
						<div class="col-sm-12" style="align-content: center;">
							<a href="#"><img style="height: 35px;width: 35px;margin-left: 10px;" src="fb.png"></a>
							<a href="#"><img style="height: 35px;width: 35px;margin-left: 20px;" src="g+.png"></a>
							<a href="#"><img style="height: 35px;width: 35px;margin-left: 20px;" src="in.png"></a>
							<a href="#"><img style="height: 35px;width: 35px;margin-left: 20px;" src="yt.png"></a>
							<a href="#"><img style="height: 35px;width: 35px;margin-left: 20px;" src="ld.png"></a>
							<br>
							<br>
						</div>

						<b>Deals in : </b>Specialist in CERA TILES , JOHNSON TILES , ADVANCE TILES & KERVIT(KAJARIA) ,<br> SANATARY WARES ,BATH FITTINGS etc. 
						<br><br><b>| Corporate | CSR Activities | Awards & Certificates | Media Couverage | Career | </b>	
						<br><br><b>Address :</b> N.H-37 , Lalungagaon , Near NPS School , Guwahati-40 (ASSAM) 
						<br><b>E-mail :</b> balajistonex8297@gmail.com
						<br><b>:Ph no</b> : 9508064697<b>,</b>9707997897 <b>.</b>
						<b><hr ></b> 
						<br><b> &copy 2018 BALAJI STONEX PVT.LTD</b>	
					</div>
				</div>


		
	</div>
</body>
</html>