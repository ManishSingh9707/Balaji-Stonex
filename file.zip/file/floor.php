<?php
/*if(isset($_GET["proid"])){
echo $proid=$_GET["proid"];
select * From Product where id='$proid'

}*/



/*
$result=mysqli_query($connect,$sql);
		if (mysqli_num_rows($result)>0) 
		{
			$_SESSION['email']=$email;

			while ($row=mysqli_fetch_assoc($result)) 
			{
				echo $row['f_name'];
				header('location:index.php');
			}
		} 

*/
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>floor</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>

<style>
	.panel-footer{
		 background-color: #B0BEC5;"
	}
	.panel-body{
		padding: 5px;
	}
</style>

</head>
<body style="background-color: #CFD8DC;">
	<div class="container-fluid">
		

<nav class="navbar navbar-inverse navbar-fixed-top" style="padding: 1px;">
			<div class="navbar-header">
				<a class="navbar-brand"><b>BALAJI STONEX</b></a>
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#nav">
						<span class="sr-only">Toggle Navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
			</div>
			<div class="collapse navbar-collapse" id="nav">
				<ul class="nav navbar-nav">
					<li class="active"><a href="index.php">HOME</a></li>
					
					<li><a href="about.php">ABOUT</a></li>
					<li><a href="#con">CONTACT</a></li>
				</ul>

				<ul class="nav navbar-nav navbar-right" style="margin-right: 20px;">
					

				<?php 

				if (!(isset($_SESSION['email']) && $_SESSION['email'] !="")) 
				{ ?>

					
					
					<li class="active"><a href="lisu.php"><span class="fa fa-sign-in"></span> Log in / Sign up</a></li>


				<?php   
					
				}

				else
					{
						if ($_SESSION['type']=="admin") 
						{  ?>
							<li class="active"><a href="admin.php"><span class="fa fa-logout"></span>Admin</a></li>
					<?php	}
						?>
						<li class="active"><a href="#"><?php echo "Hey"."   ".$_SESSION["name"]; ?></a></li>
						<li class="active"><a href="profile.php"><span class="fa fa-logout"></span>Profile</a></li>
					<li class="active"><a href="#"><span class="fa fa-shopping-cart"></span> cart</a></li>	
					<li class="active"><a href="logout.php"><span class="fa fa-logout"></span>logout</a></li>
				
					<?php  } 

				 ?>





				</ul>
			
			</div>
</nav><br><br><br>


<div class="row">
			<div class="col-md-12">
				<center><img src="img/floor/head.jpg" style="width: 100%; " class="img responsive tpad"></center>
			</div>
		</div>
	
<br>


<div>
	<a href="index.php" style="padding: 5px;">Home</a> > Floor
</div>

<br>


		<div class="row">
			<div class="col-md-3">
				<div class="panel panel-primary">
					
					<div class="panel-body" >
						<img src="img/floor/f1.jpg" class="img responsive tpad" style="width: 100%;">
					</div>
					<div class="panel-footer">
						<center>Digital floor tiles<br> size : 700 X 700 mm<br><b> Rs.520 sq/feet </b> </center>
					</div>
				</div>
			</div>


			<div class="col-md-3">
				<div class="panel panel-primary">
					
					<div class="panel-body">
						<img src="img/floor/f2.jpg" class="img responsive tpad" style="width: 100%;">
					</div>
					<div class="panel-footer">
						<center>Digital flooor tiles<br> size : 700 X 700 mm<br><b> Rs.400 sq/feet </b> </center>
					</div>
				</div>
			</div>


			<div class="col-md-3">
				<div class="panel panel-primary">
					
					<div class="panel-body">
						<img src="img/floor/f3.jpg" class="img responsive tpad" style="width: 100%;">
					</div>
					<div class="panel-footer">
						<center>Digital floor tiles<br> size : 700 X 700 mm<br><b> Rs.390 sq/feet </b> </center>
					</div>
				</div>
			</div>


			<div class="col-md-3">
				<div class="panel panel-primary">
					
					<div class="panel-body">
						<img src="img/floor/f4.jpg" class="img responsive tpad" style="width: 100%;">
					</div>
					<div class="panel-footer">
						<center>Digital floor tiles<br> size : 700 X 700 mm<br><b> Rs.400 sq/feet </b> </center>
					</div>
				</div>
			</div>


		</div>




		<div class="row">
			<div class="col-md-3">
				<div class="panel panel-primary">
					
					<div class="panel-body" >
						<img src="img/floor/f5.jpg" class="img responsive tpad" style="width: 100%;">
					</div>
					<div class="panel-footer">
						<center>Digital floor tiles<br> size : 700 X 700 mm<br><b> Rs.380 sq/feet </b> </center>
					</div>
				</div>
			</div>


			<div class="col-md-3">
				<div class="panel panel-primary">
					
					<div class="panel-body">
						<img src="img/floor/f6.jpg" class="img responsive tpad" style="width: 100%;">
					</div>
					<div class="panel-footer">
						<center>Digital floor tiles<br> size : 700 X 700 mm<br><b> Rs.350 sq/feet </b> </center>
					</div>
				</div>
			</div>


			<div class="col-md-3">
				<div class="panel panel-primary">
					
					<div class="panel-body">
						<img src="img/floor/f7.jpg" class="img responsive tpad" style="width: 100%;">
					</div>
					<div class="panel-footer">
						<center>Digital floor tiles<br> size : 700 X 700 mm<br><b> Rs.500 sq/feet </b> </center>
					</div>
				</div>
			</div>


			<div class="col-md-3">
				<div class="panel panel-primary">
					
					<div class="panel-body">
						<img src="img/floor/f8.jpg" class="img responsive tpad" style="width: 100%;">
					</div>
					<div class="panel-footer">
						<center>Digital floor tiles<br> size : 700 X 700 mm<br><b> Rs.520 sq/feet </b> </center>
					</div>
				</div>
			</div>


		</div>





<div class="row">
			<div class="col-md-3">
				<div class="panel panel-primary">
					
					<div class="panel-body" >
						<img src="img/floor/f9.jpg" class="img responsive tpad" style="width: 100%;">
					</div>
					<div class="panel-footer">
						<center>Digital floor tiles<br> size : 700 X 700 mm<br><b> Rs.400 sq/feet </b> </center>
					</div>
				</div>
			</div>


			<div class="col-md-3">
				<div class="panel panel-primary">
					
					<div class="panel-body">
						<img src="img/floor/f10.jpg" class="img responsive tpad" style="width: 100%;">
					</div>
					<div class="panel-footer">
						<center>Digital floor tiles<br> size : 700 X 700 mm<br><b> Rs.450 sq/feet </b> </center>
					</div>
				</div>
			</div>


			<div class="col-md-3">
				<div class="panel panel-primary">
					
					<div class="panel-body">
						<img src="img/floor/f11.jpg" class="img responsive tpad" style="width: 100%;height: 274px;">
					</div>
					<div class="panel-footer">
						<center>Digital floor tiles<br> size : 700 X 700 mm<br><b> Rs.540 sq/feet </b> </center>
					</div>
				</div>
			</div>


			<div class="col-md-3">
				<div class="panel panel-primary">
					
					<div class="panel-body">
						<img src="img/floor/f12.jpg" class="img responsive tpad" style="width: 100%;height: 274px;">
					</div>
					<div class="panel-footer">
						<center>Digital floor tiles<br> size : 700 X 700 mm<br><b> Rs.400 sq/feet </b> </center>
					</div>
				</div>
			</div>


		</div>






		<div class="row">
			<div class="col-md-3">
				<div class="panel panel-primary">
					
					<div class="panel-body" >
						<img src="img/floor/f13.jpg" class="img responsive tpad" style="width: 100%;">
					</div>
					<div class="panel-footer">
						<center>Digital floor tiles<br> size : 700 X 700 mm<br><b> Rs.380 sq/feet </b> </center>
					</div>
				</div>
			</div>


			<div class="col-md-3">
				<div class="panel panel-primary">
					
					<div class="panel-body">
						<img src="img/floor/f14.jpg" class="img responsive tpad" style="width: 100%;">
					</div>
					<div class="panel-footer">
						<center>Digital floor tiles<br> size : 700 X 700 mm<br><b> Rs.350 sq/feet </b> </center>
					</div>
				</div>
			</div>


			<div class="col-md-3">
				<div class="panel panel-primary">
					
					<div class="panel-body">
						<img src="img/floor/f15.jpg" class="img responsive tpad" style="width: 100%;">
					</div>
					<div class="panel-footer">
						<center>Digital floor tiles<br> size : 700 X 700 mm<br><b> Rs.500 sq/feet </b> </center>
					</div>
				</div>
			</div>


			<div class="col-md-3">
				<div class="panel panel-primary">
					
					<div class="panel-body">
						<img src="img/floor/f16.jpg" class="img responsive tpad" style="width: 100%;">
					</div>
					<div class="panel-footer">
						<center>Digital floor tiles<br> size : 700 X 700 mm<br><b> Rs.520 sq/feet </b> </center>
					</div>
				</div>
			</div>


		</div>





<div class="row">
			<div class="col-md-3">
				<div class="panel panel-primary">
					
					<div class="panel-body" >
						<img src="img/floor/f17.jpg" class="img responsive tpad" style="width: 100%;">
					</div>
					<div class="panel-footer">
						<center>Digital floor tiles<br> size : 700 X 700 mm<br><b> Rs.400 sq/feet </b> </center>
					</div>
				</div>
			</div>


			<div class="col-md-3">
				<div class="panel panel-primary">
					
					<div class="panel-body">
						<img src="img/floor/f18.jpg" class="img responsive tpad" style="width: 100%;">
					</div>
					<div class="panel-footer">
						<center>Digital floor tiles<br> size : 700 X 700 mm<br><b> Rs.450 sq/feet </b> </center>
					</div>
				</div>
			</div>


			<div class="col-md-3">
				<div class="panel panel-primary">
					
					<div class="panel-body">
						<img src="img/floor/f19.jpg" class="img responsive tpad" style="width: 100%;height: 274px;">
					</div>
					<div class="panel-footer">
						<center>Digital floor tiles<br> size : 700 X 700 mm<br><b> Rs.540 sq/feet </b> </center>
					</div>
				</div>
			</div>


			<div class="col-md-3">
				<div class="panel panel-primary">
					
					<div class="panel-body">
						<img src="img/floor/f20.jpg" class="img responsive tpad" style="width: 100%;height: 274px;">
					</div>
					<div class="panel-footer">
						<center>Digital floor tiles<br> size : 700 X 700 mm<br><b> Rs.400 sq/feet </b> </center>
					</div>
				</div>
			</div>


		</div>






<div class="row">
			<div class="col-md-3">
				<div class="panel panel-primary">
					
					<div class="panel-body" >
						<img src="img/floor/f21.jpg" class="img responsive tpad" style="width: 100%;">
					</div>
					<div class="panel-footer">
						<center>Digital floor tiles<br> size : 700 X 700 mm<br><b> Rs.400 sq/feet </b> </center>
					</div>
				</div>
			</div>


			<div class="col-md-3">
				<div class="panel panel-primary">
					
					<div class="panel-body">
						<img src="img/floor/f22.jpg" class="img responsive tpad" style="width: 100%;">
					</div>
					<div class="panel-footer">
						<center>Digital floor tiles<br> size : 700 X 700 mm<br><b> Rs.450 sq/feet </b> </center>
					</div>
				</div>
			</div>


			


		</div>



		<div class="row" id="con">
				<div class="col-sm-12" style="background-color: #455A64;padding: 40px;">
					<div class="col-sm-12" style="background-color: #90A4AE; padding: 20px;font-family: sans-serif; letter-spacing: 1px;text-align: center;">
						<div class="col-sm-12" style="align-content: center;">
							<a href="#"><img style="height: 35px;width: 35px;margin-left: 10px;" src="fb.png"></a>
							<a href="#"><img style="height: 35px;width: 35px;margin-left: 20px;" src="g+.png"></a>
							<a href="#"><img style="height: 35px;width: 35px;margin-left: 20px;" src="in.png"></a>
							<a href="#"><img style="height: 35px;width: 35px;margin-left: 20px;" src="yt.png"></a>
							<a href="#"><img style="height: 35px;width: 35px;margin-left: 20px;" src="ld.png"></a>
							<br>
							<br>
						</div>

						<b>Deals in : </b>Specialist in CERA TILES , JOHNSON TILES , ADVANCE TILES & KERVIT(KAJARIA) ,<br> SANATARY WARES ,BATH FITTINGS etc. 
						<br><br><b>| Corporate | CSR Activities | Awards & Certificates | Media Couverage | Career | </b>	
						<br><br><b>Address :</b> N.H-37 , Lalungagaon , Near NPS School , Guwahati-40 (ASSAM) 
						<br><b>E-mail :</b> balajistonex8297@gmail.com
						<br><b>:Ph no</b> : 9508064697<b>,</b>9707997897 <b>.</b>
						<b><hr ></b> 
						<br><b> &copy 2018 BALAJI STONEX PVT.LTD</b>	
					</div>
				</div>


		
	</div>




	</div>
</body>
</html>