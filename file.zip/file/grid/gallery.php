<!DOCTYPE html>
<html>
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>gallery</title>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css?family=Droid+Sans:400,700" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/baguettebox.js/1.8.1/baguetteBox.min.css">
    <link rel="stylesheet" href="gallery-grid.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.0/animate.min.css">

    <style>
        
        img{
            height: 300px;
        }
    </style>


</head>
<body style="padding-bottom: 2px;">


    <nav class="navbar navbar-inverse navbar-fixed-top" style="padding: 1px;">
            <div class="navbar-header">
                <a class="navbar-brand"><b>BALAJI STONEX</b></a>
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#nav">
                        <span class="sr-only">Toggle Navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
            </div>

            <div class="collapse navbar-collapse" id="nav">
                <ul class="nav navbar-nav">
                    <li class="active"><a href="../index.php">HOME</a></li>
                    
                    <li><a href="../about.php">ABOUT</a></li>
                    <li><a href="#">CONTACT</a></li>
                </ul>

                <ul class="nav navbar-nav navbar-right" style="margin-right: 20px;">
                    <li class="active"><a href="../#"><span class="fa fa-shopping-cart"></span> cart</a></li>
                    <li class="active"><a href="../lisu.php"><span class="fa fa-user"></span>   Sign up</a></li>
                    <li class="active"><a href="../lisu.php"><span class="fa fa-sign-in"></span> Log in</a></li>
                </ul>
            
            </div>
</nav>












<div class="container-fluid gallery-container"  style="background-color: #CFD8DC; padding-bottom: 0px;">

    <h1 class="wow bounce">Image Gallery</h1>

    <p class="page-description text-center"> - - -  Experience the beauty of tiles.  - - - </p>
    
    <div class="tz-gallery">

        <div class="row">

            <div class="col-sm-6 col-md-4 wow zoomIn delay-0.5s">
                <a class="lightbox" href="../images/i1.jpg">
                    <img src="../images/i1.jpg" alt="Park">
                </a>
            </div>
            
            <div class="col-sm-6 col-md-4 wow zoomIn delay-0.5s">
                <a class="lightbox" href="../images/i2.jpg">
                    <img src="../images/i2.jpg" alt="Bridge">
                </a>
            </div>
            
            <div class="col-sm-12 col-md-4 wow zoomIn delay-0.5s">
                <a class="lightbox" href="../images/i3.jpg">
                    <img src="../images/i3.jpg" alt="Tunnel">
                </a>
            </div>
            
            <div class="col-sm-6 col-md-4 wow zoomIn delay-0.5s">
                <a class="lightbox" href="../images/i4.jpg">
                    <img src="../images/i4.jpg" alt="Coast">
                </a>
            </div>
            
           
            
            <div class="col-sm-6 col-md-4 wow zoomIn delay-0.5s">
                <a class="lightbox" href="../images/i6.jpg">
                    <img src="../images/i6.jpg" alt="Traffic">
                </a>
            </div>
            
            <div class="col-sm-6 col-md-4 wow zoomIn delay-0.5s">
                <a class="lightbox" href="../images/i7.jpg">
                    <img src="../images/i7.jpg" alt="Rocks">
                </a>
            </div>
            
            <div class="col-sm-6 col-md-4 wow zoomIn delay-0.5s">
                <a class="lightbox" href="../images/i8.jpg">
                    <img src="../images/i8.jpg" alt="Benches">
                </a>
            </div>
            
            <div class="col-sm-6 col-md-4 wow zoomIn delay-0.5s">
                <a class="lightbox" href="../images/i9.jpg">
                    <img src="../images/i9.jpg" alt="Sky">
                </a>
            </div>

            <div class="col-sm-6 col-md-4 wow zoomIn delay-0.5s">
                <a class="lightbox" href="../images/i10.jpg">
                    <img src="../images/i10.jpg" alt="Sky">
                </a>
            </div>

            <div class="col-sm-6 col-md-4 wow zoomIn delay-0.5s">
                <a class="lightbox" href="../images/i11.jpg">
                    <img src="../images/i11.jpg" alt="Park">
                </a>
            </div>
            
            <div class="col-sm-6 col-md-4 wow zoomIn delay-0.5s">
                <a class="lightbox" href="../images/i12.jpg">
                    <img src="../images/i12.jpg" alt="Bridge">
                </a>
            </div>
            
            <div class="col-sm-12 col-md-4 wow zoomIn delay-0.5s">
                <a class="lightbox" href="../images/i13.jpg">
                    <img src="../images/i13.jpg" alt="Tunnel">
                </a>
            </div>
            
           
            
            <div class="col-sm-6 col-md-4 wow zoomIn delay-0.5s">
                <a class="lightbox" href="../images/i15.jpg">
                    <img src="../images/i15.jpg" alt="Rails">
                </a>
            </div>
            
            <div class="col-sm-6 col-md-4 wow zoomIn delay-0.5s">
                <a class="lightbox" href="../images/i16.jpg">
                    <img src="../images/i16.jpg" alt="Traffic">
                </a>
            </div>
            
            <div class="col-sm-6 col-md-4 wow zoomIn delay-0.5s">
                <a class="lightbox" href="../images/i17.jpg">
                    <img src="../images/i17.jpg" alt="Rocks">
                </a>
            </div>
            
            <div class="col-sm-6 col-md-4 wow zoomIn delay-0.5s">
                <a class="lightbox" href="../images/i18.jpg">
                    <img src="../images/i18.jpg" alt="Benches">
                </a>
            </div>
            
            <div class="col-sm-6 col-md-4 wow zoomIn delay-0.5s">
                <a class="lightbox" href="../images/i19.jpg">
                    <img src="../images/i19.jpg" alt="Sky">
                </a>
            </div>

            <div class="col-sm-6 col-md-4 wow zoomIn delay-0.5s">
                <a class="lightbox" href="../images/i20.jpg">
                    <img src="../images/i20.jpg" alt="Sky">
                </a>
            </div>


            <div class="col-sm-6 col-md-4 wow zoomIn delay-0.5s">
                <a class="lightbox" href="../images/i21.jpg">
                    <img src="../images/i21.jpg" alt="Park">
                </a>
            </div>
            
            <div class="col-sm-6 col-md-4 wow zoomIn delay-0.5s">
                <a class="lightbox" href="../images/i22.jpg">
                    <img src="../images/i22.jpg" alt="Bridge">
                </a>
            </div>
            
            <div class="col-sm-12 col-md-4 wow zoomIn delay-0.5s">
                <a class="lightbox" href="../images/i23.jpg">
                    <img src="../images/i23.jpg" alt="Tunnel">
                </a>
            </div>
            
           
            
            <div class="col-sm-6 col-md-4 wow zoomIn delay-0.5s">
                <a class="lightbox" href="../images/i25.jpg">
                    <img src="../images/i25.jpg" alt="Rails">
                </a>
            </div>
            
            <div class="col-sm-6 col-md-4 wow zoomIn delay-0.5s">
                <a class="lightbox" href="../images/i26.jpg">
                    <img src="../images/i26.jpg" alt="Traffic">
                </a>
            </div>
            
            <div class="col-sm-6 col-md-4 wow zoomIn delay-0.5s">
                <a class="lightbox" href="../images/i27.jpg">
                    <img src="../images/i27.jpg" alt="Rocks">
                </a>
            </div>
            
            <div class="col-sm-6 col-md-4 wow zoomIn delay-0.5s">
                <a class="lightbox" href="../images/i28.jpg">
                    <img src="../images/i28.jpg" alt="Benches">
                </a>
            </div>
            
            <div class="col-sm-6 col-md-4 wow zoomIn delay-0.5s">
                <a class="lightbox" href="../images/i29.jpg">
                    <img src="../images/i29.jpg" alt="Sky">
                </a>
            </div>

            <div class="col-sm-6 col-md-4 wow zoomIn delay-0.5s">
                <a class="lightbox" href="../images/i30.jpg">
                    <img src="../images/i30.jpg" alt="Sky">
                </a>
            </div>


            <div class="col-sm-6 col-md-4 wow zoomIn delay-0.5s">
                <a class="lightbox" href="../images/i31.jpg">
                    <img src="../images/i31.jpg" alt="Sky">
                </a>
            </div>

            <div class="col-sm-6 col-md-4 wow zoomIn delay-0.5s">
                <a class="lightbox" href="../images/i32.jpg">
                    <img src="../images/i32.jpg" alt="Sky">
                </a>
            </div>

             <div class="col-sm-6 col-md-4 wow zoomIn delay-0.5s">
                <a class="lightbox" href="../images/i5.jpg">
                    <img src="../images/i5.jpg" alt="Rails">
                </a>
            </div>

             <div class="col-sm-6 col-md-4 wow zoomIn delay-0.5s">
                <a class="lightbox" href="../images/i14.jpg">
                    <img src="../images/i14.jpg" alt="Coast">
                </a>
            </div>

        </div>

    </div>


    <div class="row">
                <div class="col-sm-12" style="background-color: #455A64;padding: 40px;">
                    <div class="col-sm-12" style="background-color: #90A4AE; padding: 20px;font-family: sans-serif; letter-spacing: 1px;text-align: center;">
                        <div class="col-sm-12" style="align-content: center;">
                            <a href="#"><img style="height: 35px;width: 35px;margin-left: 10px;" src="../fb.png"></a>
                            <a href="#"><img style="height: 35px;width: 35px;margin-left: 20px;" src="../g+.png"></a>
                            <a href="#"><img style="height: 35px;width: 35px;margin-left: 20px;" src="../in.png"></a>
                            <a href="#"><img style="height: 35px;width: 35px;margin-left: 20px;" src="../yt.png"></a>
                            <a href="#"><img style="height: 35px;width: 35px;margin-left: 20px;" src="../ld.png"></a>
                            <br>
                            <br>
                        </div>

                        <b>Deals in : </b>Specialist in CERA TILES , JOHNSON TILES , ADVANCE TILES & KERVIT(KAJARIA) ,<br> SANATARY WARES ,BATH FITTINGS etc. 
                        <br><br><b>| Corporate | CSR Activities | Awards & Certificates | Media Couverage | Career | </b>   
                        <br><br><b>Address :</b> N.H-37 , Lalungagaon , Near NPS School , Guwahati-40 (ASSAM) 
                        <br><b>E-mail :</b> balajistonex8297@gmail.com
                        <br><b>:Ph no</b> : 9508064697<b>,</b>9707997897 <b>.</b>
                        <b><hr ></b> 
                        <br><b> &copy 2018 BALAJI STONEX PVT.LTD</b>    
                    </div>
                </div>
            </div>




</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/baguettebox.js/1.8.1/baguetteBox.min.js"></script>
<script>
    baguetteBox.run('.tz-gallery');
</script>


<script src=https://cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.js> </script>
<script>
    var wow = new WOW(
  {
    boxClass:     'wow',      // animated element css class (default is wow)
    animateClass: 'animated', // animation css class (default is animated)
    offset:       0,          // distance to the element when triggering the animation (default is 0)
    mobile:       true,       // trigger animations on mobile devices (default is true)
    live:         true,       // act on asynchronously loaded content (default is true)
    callback:     function(box) {
      // the callback is fired every time an animation is started
      // the argument that is passed in is the DOM node being animated
    },
    scrollContainer: null,    // optional scroll container selector, otherwise use window,
    resetAnimation: true,     // reset animation on end (default is true)
  }
);
wow.init();

</script>

</body>
</html>