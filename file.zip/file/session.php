<?php 


session_start();
$result=mysqli_query($connect,$sql);
if (mysqli_num_rows($result)>0) 
{
	$_SESSION['email']=$email;

	while ($row=mysqli_fetch_assoc($result)) 
	{
		$_SESSION['name']=$row['fname'];
		header('location:index.php');
	}
}

 ?>